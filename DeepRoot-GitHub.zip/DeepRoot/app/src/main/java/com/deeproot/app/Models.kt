package com.deeproot.app

import org.json.JSONArray
import org.json.JSONObject

data class ToolCall(val id: String, val name: String, val args: String)

data class Msg(
    val role: String,                       // user | assistant | tool
    val content: String = "",
    val reasoning: String = "",             // 深度思考内容
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,         // role=tool 时对应的调用 id
    val denied: Boolean = false,            // 用户是否拒绝执行
)

data class Chat(val id: String, val title: String, val msgs: List<Msg>, val updated: Long)

data class Pending(val callId: String, val command: String, val reason: String, val dangerous: Boolean)

data class Settings(
    val apiKey: String = "",
    val baseUrl: String = "https://api.deepseek.com",
    val system: String = DEFAULT_SYSTEM,
)

const val DEFAULT_SYSTEM =
    "你是运行在用户 Android 手机上的助手。需要查看或修改系统时，调用 run_shell 工具执行 shell 命令（root 权限）。" +
    "规则：1) 每次只执行一条命令；2) 优先使用只读命令；3) 破坏性命令（删除、格式化、写分区等）必须先向用户说明风险；" +
    "4) 每条命令都会先经用户确认，被拒绝后不要重复请求同一命令；5) 根据命令输出继续分析并用中文回答。"

/** 暴露给模型的唯一工具：执行 shell 命令（每次都需要用户批准） */
val TOOLS: JSONArray = JSONArray().put(
    JSONObject()
        .put("type", "function")
        .put(
            "function", JSONObject()
                .put("name", "run_shell")
                .put("description", "在用户手机上以 root 身份执行一条 shell 命令并返回输出。每条命令都会先经用户确认。")
                .put(
                    "parameters", JSONObject()
                        .put("type", "object")
                        .put(
                            "properties", JSONObject()
                                .put("command", JSONObject().put("type", "string").put("description", "要执行的 shell 命令"))
                                .put("reason", JSONObject().put("type", "string").put("description", "用一句话向用户解释为什么要执行"))
                        )
                        .put("required", JSONArray().put("command").put("reason"))
                )
        )
)

private val DANGEROUS = listOf(
    Regex("""\brm\s+(-[a-zA-Z]*\s+)*(/|/\*|/data|/system|/sdcard|/storage|\$HOME|~)(\s|$)"""),
    Regex("""\bdd\s+.*\bof=/dev/"""),
    Regex("""\bmkfs"""), Regex("""\bwipe\b"""), Regex("""\bformat\b"""),
    Regex(""">\s*/dev/block"""), Regex("""\b(reboot|poweroff)\b"""),
    Regex("""\bsetprop\b"""), Regex("""\bresetprop\b"""),
    Regex("""\bpm\s+(uninstall|clear|disable)"""), Regex("""\bchmod\s+(-R\s+)?777\s+/"""),
    Regex("""\bfastboot\b"""), Regex("""\bflash\b"""), Regex("""\bmount\b.*\b(rw|remount)\b"""),
)

fun isDangerous(cmd: String) = DANGEROUS.any { it.containsMatchIn(cmd) }
