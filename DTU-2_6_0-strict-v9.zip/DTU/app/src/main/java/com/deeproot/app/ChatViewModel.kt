package com.deeproot.app

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.security.MessageDigest

private const val PLACEHOLDER_TITLE = "新对话"
private val TITLE_PLACEHOLDERS = setOf("", PLACEHOLDER_TITLE, "附件对话")

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val api = DeepSeekApi()

    val chats = MutableStateFlow(store.loadChats())
    val currentId = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)
    val pending = MutableStateFlow<Pending?>(null)
    val settings = MutableStateFlow(store.loadSettings())
    val deepThink = MutableStateFlow(store.loadToggle("deep_think"))
    val webSearch = MutableStateFlow(store.loadToggle("web_search"))
    /** 严格模式：开启后所有终端操作都需确认；默认关闭（只读命令直接执行） */
    val strictMode = MutableStateFlow(store.loadToggle("strict_mode"))

    // ---- 字体 ----
    val fontKey = MutableStateFlow(store.loadFont())
    val customFontName = MutableStateFlow(store.loadCustomFont()?.first)
    /** 用户导入的字体文件路径；每次导入用新文件名，避免系统缓存旧字体 */
    val customFontPath = MutableStateFlow(
        store.loadCustomFont()?.second?.let { java.io.File(app.filesDir, it) }?.takeIf { it.exists() }?.path
    )
    val fontError = MutableStateFlow<String?>(null)

    fun setFont(key: String) { fontKey.value = key; store.saveFont(key) }

    fun importFont(uri: Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val ctx = getApplication<Application>()
            runCatching {
                val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) c.getString(i) else null
                }?.substringBeforeLast('.') ?: "自定义字体"
                val tmp = java.io.File(ctx.filesDir, "custom_font.tmp")
                ctx.contentResolver.openInputStream(uri)!!.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
                val head = ByteArray(4).also { b -> tmp.inputStream().use { it.read(b) } }
                val tag = String(head, Charsets.ISO_8859_1)
                val valid = tmp.length() in 1..(40L * 1024 * 1024) &&
                    (tag == "OTTO" || tag == "true" || tag == "ttcf" || head.contentEquals(byteArrayOf(0, 1, 0, 0)))
                if (!valid) {
                    tmp.delete()
                    fontError.value = "不是有效的字体文件（支持 .ttf / .otf / .ttc）"
                    return@runCatching
                }
                val fileName = "custom_font_${System.currentTimeMillis()}.ttf"
                val dst = java.io.File(ctx.filesDir, fileName)
                tmp.copyTo(dst, overwrite = true); tmp.delete()
                customFontPath.value?.let { java.io.File(it).delete() }
                store.saveCustomFont(name, fileName)
                customFontName.value = name
                customFontPath.value = dst.path
                fontError.value = null
                setFont("custom")
            }.onFailure { fontError.value = "导入失败：${it.message}" }
        }
    }
    val error = MutableStateFlow<String?>(null)
    val rootState = MutableStateFlow<Boolean?>(null)
    val modelOptions = MutableStateFlow(
        if (settings.value.modelCacheFingerprint == modelFingerprint(settings.value.baseUrl, settings.value.apiKey) && settings.value.modelOptions.isNotEmpty()) settings.value.modelOptions
        else listOf("deepseek-flash", "deepseek-v4-pro")
    )
    val modelFetchState = MutableStateFlow<String?>(null)
    private var modelFetchJob: Job? = null

    init {
        RootShell.init(app)
        // 记住“深度思考 / 联网搜索”开关：每次变化立即落盘，下次启动恢复上次状态
        viewModelScope.launch { deepThink.drop(1).collect { store.saveToggle("deep_think", it) } }
        viewModelScope.launch { webSearch.drop(1).collect { store.saveToggle("web_search", it) } }
        viewModelScope.launch { strictMode.drop(1).collect { store.saveToggle("strict_mode", it) } }
    }

    private var job: Job? = null
    private val titling = mutableSetOf<String>()
    private var decision: CompletableDeferred<Boolean>? = null

    fun newChat() { if (!busy.value) currentId.value = null }
    fun select(id: String) { if (!busy.value) currentId.value = id }
    fun rename(id: String, title: String) {
        val t = title.trim().take(40)
        if (t.isBlank()) return
        chats.update { l -> l.map { if (it.id == id) it.copy(title = t) else it } }
        store.saveChats(chats.value)
    }
    fun togglePin(id: String) {
        chats.update { l -> l.map { if (it.id == id) it.copy(pinned = !it.pinned) else it } }
        store.saveChats(chats.value)
    }
    fun deleteMany(ids: Set<String>) {
        if (busy.value || ids.isEmpty()) return
        chats.update { l -> l.filter { it.id !in ids } }
        if (currentId.value in ids) currentId.value = null
        store.saveChats(chats.value)
    }
    fun delete(id: String) {
        if (busy.value) return
        chats.update { l -> l.filter { it.id != id } }
        if (currentId.value == id) currentId.value = null
        store.saveChats(chats.value)
    }

    fun saveSettings(s: Settings) {
        val fingerprint = if (s.apiKey.isNotBlank()) modelFingerprint(s.baseUrl, s.apiKey) else ""
        val cacheMatches = fingerprint.isNotBlank() && fingerprint == settings.value.modelCacheFingerprint
        val options = if (cacheMatches) modelOptions.value else listOf("deepseek-flash", "deepseek-v4-pro")
        modelOptions.value = options
        val selected = s.model.ifBlank { options.firstOrNull() ?: "deepseek-flash" }
        val saved = s.copy(model = selected, modelOptions = options, modelCacheFingerprint = if (cacheMatches) fingerprint else "")
        settings.value = saved
        store.saveSettings(saved)
    }

    fun fetchModels(base: String, key: String) {
        if (base.isBlank() || key.isBlank()) {
            modelFetchState.value = "请先填写 API Base URL 和 API Key"
            return
        }
        modelFetchJob?.cancel()
        modelFetchJob = viewModelScope.launch {
            modelFetchState.value = "正在获取模型列表…"
            try {
                val list = api.listModels(base, key)
                modelOptions.value = list
                val fp = modelFingerprint(base, key)
                val current = settings.value
                val selected = current.model.takeIf { it in list } ?: list.first()
                val updated = current.copy(apiKey = key, baseUrl = base, model = selected, modelOptions = list, modelCacheFingerprint = fp)
                settings.value = updated
                store.saveSettings(updated)
                modelFetchState.value = "已获取 ${list.size} 个模型"
            } catch (e: Exception) {
                modelFetchState.value = "获取失败：${e.message ?: "未知错误"}。已保留上次模型列表。"
            }
        }
    }

    private fun modelFingerprint(base: String, key: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest((base.trim().trimEnd('/') + "|" + key).toByteArray())
        return bytes.take(12).joinToString("") { "%02x".format(it) }
    }

    /** 点击后会弹出 su 授权（Magisk / KernelSU / APatch） */
    fun checkRoot() {
        viewModelScope.launch { rootState.value = runCatching { RootShell.isRoot() }.getOrDefault(false) }
    }

    /** 用户对某条命令的决定：true=允许执行一次，false=拒绝 */
    fun approve(ok: Boolean) { decision?.complete(ok) }

    fun stop() { job?.cancel() }

    fun addAttachments(uris: List<Uri>) {
        if (busy.value) return
        var id = currentId.value
        if (id == null) {
            id = UUID.randomUUID().toString()
            chats.update { listOf(Chat(id!!, "附件对话", listOf(Msg("user")), System.currentTimeMillis())) + it }
            currentId.value = id
        }
        val chatId = id ?: return
        val ctx = getApplication<Application>()
        val added = uris.mapNotNull { uri ->
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "attachment"
            val mime = ctx.contentResolver.getType(uri) ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
            if (!isSupportedAttachment(name, mime)) { error.value = "暂不支持该文件类型：$name"; null } else Attachment(uri.toString(), name, mime)
        }
        if (added.isNotEmpty()) mutate(chatId) { chat ->
            val last = chat.msgs.lastOrNull()
            if (last?.role == "user") chat.copy(msgs = chat.msgs.dropLast(1) + last.copy(attachments = last.attachments + added))
            else chat.copy(msgs = chat.msgs + Msg("user", attachments = added))
        }
        store.saveChats(chats.value)
    }

    fun removeAttachment(uri: String) {
        val id = currentId.value ?: return
        mutate(id) { chat -> val last = chat.msgs.lastOrNull(); if (last?.role == "user") chat.copy(msgs = chat.msgs.dropLast(1) + last.copy(attachments = last.attachments.filterNot { it.uri == uri })) else chat }
        store.saveChats(chats.value)
    }

    private fun isSupportedAttachment(name: String, mime: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext in setOf("mp4", "mkv", "mov", "avi", "webm", "3gp", "mpeg", "mpg")) return false
        return (mime in setOf("image/jpeg", "image/png", "image/gif", "image/webp") && ext in setOf("jpg", "jpeg", "png", "gif", "webp")) || ext in setOf("pdf", "doc", "docx", "ppt", "pptx", "txt", "md", "csv", "json", "xls", "xlsx", "epub", "mobi", "kt", "java", "py", "js", "html", "xml", "log")
    }

    fun send(text: String) {
        if (busy.value) return
        val current = currentId.value?.let { id -> chats.value.firstOrNull { it.id == id } }
        val pendingAttachments = current?.msgs?.lastOrNull()?.takeIf { it.role == "user" }?.attachments.orEmpty()
        if (text.isBlank() && pendingAttachments.isEmpty()) return
        if (settings.value.apiKey.isBlank()) { error.value = "请先在设置中填写 API Key"; return }
        var id = currentId.value
        if (id == null || chats.value.none { it.id == id }) {
            id = UUID.randomUUID().toString()
            chats.update { listOf(Chat(id, PLACEHOLDER_TITLE, emptyList(), System.currentTimeMillis())) + it }
            currentId.value = id
        }
        val existingLast = chats.value.firstOrNull { it.id == id }?.msgs?.lastOrNull()
        if (existingLast?.role == "user" && existingLast.attachments.isNotEmpty()) {
            mutate(id) { chat -> chat.copy(msgs = chat.msgs.dropLast(1) + existingLast.copy(content = text), updated = System.currentTimeMillis()) }
        } else mutate(id) { it.copy(msgs = it.msgs + Msg("user", text), updated = System.currentTimeMillis()) }
        // 对话标题：概括第一句话，而不是直接复制原文
        val chatId: String = id
        chats.value.firstOrNull { it.id == chatId }?.let { c ->
            if (c.title in TITLE_PLACEHOLDERS && titling.add(chatId)) {
                val src = text.ifBlank {
                    c.msgs.lastOrNull { it.role == "user" }?.attachments?.joinToString("、") { it.name }?.let { "文件：$it" }.orEmpty()
                }
                autoTitle(chatId, src)
            }
        }
        run(id)
    }

    private fun autoTitle(cid: String, source: String) {
        val s = settings.value
        viewModelScope.launch {
            val ai = runCatching { api.summarizeTitle(s.baseUrl, s.apiKey, s.model, source) }.getOrNull()?.takeIf { it.isNotBlank() }
            val title = ai ?: fallbackTitle(source)
            mutate(cid) { if (it.title in TITLE_PLACEHOLDERS) it.copy(title = title) else it }
            titling.remove(cid)
            store.saveChats(chats.value)
        }
    }

    /** 网络或模型失败时的本地概括：取第一个分句，去掉“请帮我”之类的客套前缀。 */
    private fun fallbackTitle(t: String): String {
        val first = t.trim().lineSequence().firstOrNull().orEmpty()
            .split(Regex("[。！？!?.，,；;]")).firstOrNull { it.isNotBlank() }.orEmpty().trim()
            .replace(Regex("^(你好|您好|嗨|请问|请你|请|麻烦|帮我|帮忙|我想要|我想|能不能|能否|可以)+"), "").trim()
        return first.ifBlank { PLACEHOLDER_TITLE }.take(14)
    }

    /** 重新生成：丢弃最后一条用户消息之后的内容并重发 */
    fun regenerate() {
        val id = currentId.value ?: return
        if (busy.value) return
        mutate(id) { c ->
            val i = c.msgs.indexOfLast { it.role == "user" }
            if (i < 0) c else c.copy(msgs = c.msgs.take(i + 1))
        }
        run(id)
    }

    private fun run(cid: String) {
        busy.value = true
        job = viewModelScope.launch {
            try {
                agentLoop(cid)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error.value = e.message ?: e.toString()
            } finally {
                busy.value = false
                pending.value = null
                cleanup(cid)
                store.saveChats(chats.value)
            }
        }
    }

    private suspend fun agentLoop(cid: String) {
        repeat(12) {
            val s = settings.value
            val history = buildMessages(cid, s)
            mutate(cid) { it.copy(msgs = it.msgs + Msg("assistant")) }
            val c = StringBuilder(); val r = StringBuilder(); var last = 0L
            fun push() {
                val n = SystemClock.uptimeMillis()
                if (n - last < 60) return
                last = n
                val raw = c.toString(); val rs = r.toString()
                val start = raw.indexOf("<progress>")
                val end = if (start >= 0) raw.indexOf("</progress>", start + 10) else -1
                val progress = if (start >= 0 && end >= 0) raw.substring(start + 10, end).trim() else ""
                val visible = if (start >= 0 && end >= 0) (raw.substring(0, start) + raw.substring(end + 11)).trimStart() else if (start >= 0) raw.substring(0, start).trimStart() else raw
                mutate(cid) { ch -> ch.copy(msgs = ch.msgs.dropLast(1) + ch.msgs.last().copy(content = visible, reasoning = rs, progress = progress)) }
            }
            val hasImage = chats.value.firstOrNull { it.id == cid }?.msgs?.any { m -> m.attachments.any { it.mime.startsWith("image/") } } == true
            val model = if (hasImage || chats.value.firstOrNull { it.id == cid }?.msgs?.any { it.attachments.isNotEmpty() } == true) "deepseek-flash" else if (deepThink.value && s.model == "deepseek-chat") "deepseek-reasoner" else s.model
            val activeTools = JSONArray().apply {
                for (i in 0 until TOOLS.length()) put(TOOLS.get(i))
                if (webSearch.value) for (i in 0 until WEB_TOOLS.length()) put(WEB_TOOLS.get(i))
            }
            val res = api.stream(s.baseUrl, s.apiKey, model, history, activeTools, deepThink.value,
                { r.append(it); push() }, { c.append(it); push() })
            val planStart = res.content.indexOf("<progress>")
            val planEnd = if (planStart >= 0) res.content.indexOf("</progress>", planStart + 10) else -1
            val finalProgress = if (planStart >= 0 && planEnd >= 0) res.content.substring(planStart + 10, planEnd).trim() else ""
            val finalContent = if (planStart >= 0 && planEnd >= 0)
                (res.content.substring(0, planStart) + res.content.substring(planEnd + 11)).trimStart()
                else res.content
            mutate(cid) { ch ->
                ch.copy(msgs = ch.msgs.dropLast(1) +
                    ch.msgs.last().copy(content = finalContent, reasoning = res.reasoning, progress = finalProgress, toolCalls = res.toolCalls))
            }
            if (res.toolCalls.isEmpty()) return

            for (tc in res.toolCalls) {
                val args = runCatching { JSONObject(tc.args) }.getOrDefault(JSONObject())
                val cmd = args.optString("command")
                val why = args.optString("reason")
                var denied = false
                val out = when {
                    tc.name == "web_search" -> runCatching { WebTools.search(s.baseUrl, s.apiKey, args.optString("query")) }.getOrElse { "搜索失败：${it.message ?: "未知错误"}" }
                    tc.name == "read_url" -> runCatching { WebTools.readUrl(s.baseUrl, s.apiKey, args.optString("url")) }.getOrElse { "网页读取失败：${it.message ?: "未知错误"}" }
                    tc.name != "run_shell" || cmd.isBlank() -> "错误：未知工具或缺少 command 参数"
                    else -> {
                        // 每条命令执行前实时读取严格模式：对话中途切换立即生效
                        if (!strictMode.value && isReadOnly(cmd)) {
                            RootShell.exec(cmd)
                        } else {
                            val d = CompletableDeferred<Boolean>()
                            decision = d
                            pending.value = Pending(tc.id, cmd, why, isDangerous(cmd))
                            // 等待确认期间若关闭严格模式，且该命令是只读的，则无需再确认，自动放行
                            val ok = coroutineScope {
                                val watcher = launch { strictMode.collect { strict -> if (!strict && isReadOnly(cmd)) d.complete(true) } }
                                try { d.await() } finally { watcher.cancel() }
                            }
                            pending.value = null
                            if (ok) RootShell.exec(cmd) else { denied = true; "用户拒绝执行该命令" }
                        }
                    }
                }
                mutate(cid) { it.copy(msgs = it.msgs + Msg("tool", out, toolCallId = tc.id, denied = denied)) }
            }
        }
    }

    private suspend fun buildMessages(cid: String, s: Settings): JSONArray {
        var msgs = chats.value.first { it.id == cid }.msgs
        val ctx = getApplication<Application>()
        msgs.forEachIndexed { index, msg ->
            if (msg.role == "user" && msg.attachments.any { it.fileId.isBlank() }) {
                val updated = msg.attachments.map { a ->
                    if (a.fileId.isNotBlank()) a else a.copy(fileId = api.uploadFile(ctx, s.baseUrl, s.apiKey, a), purpose = when { a.mime.startsWith("image/") -> "user_data"; a.name.substringAfterLast('.', "").lowercase() in setOf("txt", "md", "csv", "json", "xlsx", "xls", "epub", "mobi", "kt", "java", "py", "js", "html", "xml", "log") -> "user_data"; a.name.substringAfterLast('.', "").lowercase() in setOf("pdf", "ppt", "pptx") -> "rich_layout_recognition"; else -> "text_recognition" })
                }
                mutate(cid) { chat -> chat.copy(msgs = chat.msgs.mapIndexed { i, m -> if (i == index) m.copy(attachments = updated) else m }) }
            }
        }
        msgs = chats.value.first { it.id == cid }.msgs
        val lastUser = msgs.indexOfLast { it.role == "user" }
        val webNote = if (webSearch.value) "\n\n【后台联网模式】今天是" + java.text.SimpleDateFormat("yyyy年M月d日 EEEE", java.util.Locale.CHINA).format(java.util.Date()) +
            "。需要最新信息时必须调用 web_search；资料不足或需要核实时调用 read_url 阅读网页正文。检索与网页读取均在后台完成，用户界面不会展示搜索卡片、网页标题列表、URL、原始摘要或工具调用过程。你必须先综合多个可靠资料，再直接用自然、连贯的中文回答用户，不要描述自己正在搜索，不要输出搜索结果清单或逐条罗列网页，不要主动附上来源链接/引用标记；只有用户明确询问来源、出处或链接时，才根据工具返回的真实资料提供来源。不得编造未检索到的事实；资料不足时如实说明。" else ""
        val modeNote = if (strictMode.value) "\n\n【当前终端确认模式：严格模式已开启】所有 run_shell 命令（包括只读命令）都会先经用户确认。用户可能在对话中随时切换该模式，以本条说明为准，忽略之前对话里关于确认方式的任何结论。"
            else "\n\n【当前终端确认模式：严格模式已关闭】只读命令会直接执行，其余命令仍需用户确认。用户可能在对话中随时切换该模式，以本条说明为准，忽略之前对话里关于确认方式的任何结论。"
        val progressNote = "\n\n【公开工作提要格式】在开始正式回答前，先用 <progress>...</progress> 输出面向用户的简短工作提要，最多 3 条，每条说明一个阶段的目的或将采取的行动，简洁、可验证，不超过 60 个汉字。它是工作计划摘要，不是思维链。不得输出隐藏推理、逐步内心独白、token 级思考或详细推导。随后直接给出正式答案。简单问候、简单事实问题可省略提要。若需要调用工具，提要应概括任务目标，不要披露内部推理。"
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", s.system + modeNote + webNote + progressNote))
        msgs.forEachIndexed { i, m ->
            val o = JSONObject().put("role", m.role)
            when (m.role) {
                "assistant" -> {
                    o.put("content", m.content)
                    if (m.toolCalls.isNotEmpty()) {
                        o.put("tool_calls", JSONArray().also { a ->
                            m.toolCalls.forEach {
                                a.put(JSONObject().put("id", it.id).put("type", "function")
                                    .put("function", JSONObject().put("name", it.name).put("arguments", it.args)))
                            }
                        })
                        // 思考模式下，同一轮的工具调用需要回传 reasoning_content
                        if (i > lastUser && m.reasoning.isNotEmpty()) o.put("reasoning_content", m.reasoning)
                    }
                }
                "tool" -> o.put("tool_call_id", m.toolCallId).put("content", m.content)
                else -> {
                    if (m.attachments.isEmpty()) o.put("content", m.content) else {
                        val blocks = JSONArray()
                        if (m.content.isNotBlank()) blocks.put(JSONObject().put("type", "text").put("text", m.content))
                        m.attachments.forEach { blocks.put(JSONObject().put("type", "file").put("file_id", it.fileId)) }
                        o.put("content", blocks)
                    }
                }
            }
            arr.put(o)
        }
        return arr
    }

    /** 被中断时补齐未应答的 tool_call，并清掉空的占位消息，避免下次请求 400 */
    private fun cleanup(cid: String) {
        mutate(cid) { ch ->
            var l = ch.msgs
            val last = l.lastOrNull()
            if (last != null && last.role == "assistant" && last.content.isEmpty() && last.reasoning.isEmpty() && last.progress.isEmpty() && last.toolCalls.isEmpty())
                l = l.dropLast(1)
            val ai = l.indexOfLast { it.role == "assistant" && it.toolCalls.isNotEmpty() }
            if (ai >= 0) {
                val answered = l.drop(ai + 1).filter { it.role == "tool" }.mapNotNull { it.toolCallId }.toSet()
                val missing = l[ai].toolCalls.filter { it.id !in answered }
                l = l + missing.map { Msg("tool", "已取消", toolCallId = it.id, denied = true) }
            }
            ch.copy(msgs = l)
        }
    }

    private fun mutate(id: String, f: (Chat) -> Chat) {
        chats.update { l -> l.map { if (it.id == id) f(it) else it } }
    }
}
