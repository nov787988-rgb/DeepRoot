package com.deeproot.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: ChatViewModel = viewModel()
            val fontKey by vm.fontKey.collectAsState()
            val customPath by vm.customFontPath.collectAsState()
            val fontSpec = remember(fontKey, customPath) { AppFontSpec(fontKey, customPath) }
            DTUTheme(fontSpec) {
                // 启动动画只在冷启动播放一次；旋转屏幕等重建不会重播
                var splashDone by rememberSaveable { mutableStateOf(false) }
                var titleBounds by remember { mutableStateOf<Rect?>(null) }
                Box(Modifier.fillMaxSize()) {
                    App(vm, titleAlpha = if (splashDone) 1f else 0f, onTitleBounds = { titleBounds = it })
                    if (!splashDone) SplashOverlay(target = { titleBounds }, onFinished = { splashDone = true })
                }
            }
        }
    }
}
