package com.deeproot.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** 自绘图标集：24×24 网格，圆头圆角描边 + 饱满实心块面，统一风格，不依赖任何图标库或字符。 */
enum class Ic { Menu, Plus, LockClosed, LockOpen, Bulb, Globe, Send, Stop, Sliders, Search, Close, ChevronDown, ChevronRight, File, Check, Refresh, Copy, Terminal, Edit, Pin, Checklist, Trash, Back, Key, Link, Chip, Font, Chat }

@Composable
fun Icon24(kind: Ic, tint: Color, iconSize: Dp = 22.dp, modifier: Modifier = Modifier, weight: Float = 2.3f) {
    // Offscreen 合成：镂空（BlendMode.Clear）只擦除图标自身，不会擦到背景
    Canvas(modifier.then(Modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }).size(iconSize)) {
        val k = this.size.minDimension / 24f
        val sw = weight * k
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun o(x: Float, y: Float) = Offset(x * k, y * k)
        fun ln(ax: Float, ay: Float, bx: Float, by: Float, w: Float = sw, clear: Boolean = false) =
            drawLine(if (clear) Color.Black else tint, o(ax, ay), o(bx, by), w, StrokeCap.Round, blendMode = if (clear) BlendMode.Clear else BlendMode.SrcOver)
        fun rr(x: Float, y: Float, w: Float, h: Float, r: Float, fill: Boolean = true, clear: Boolean = false) =
            drawRoundRect(if (clear) Color.Black else tint, o(x, y), Size(w * k, h * k), CornerRadius(r * k),
                style = if (fill) androidx.compose.ui.graphics.drawscope.Fill else st, blendMode = if (clear) BlendMode.Clear else BlendMode.SrcOver)
        fun dot(x: Float, y: Float, r: Float, clear: Boolean = false) =
            drawCircle(if (clear) Color.Black else tint, r * k, o(x, y), blendMode = if (clear) BlendMode.Clear else BlendMode.SrcOver)

        when (kind) {
            Ic.Menu -> { ln(4.5f, 8f, 19.5f, 8f, 2.6f * k); ln(4.5f, 16f, 13.5f, 16f, 2.6f * k) }
            Ic.Plus -> { ln(12f, 5f, 12f, 19f, 2.7f * k); ln(5f, 12f, 19f, 12f, 2.7f * k) }
            Ic.LockClosed, Ic.LockOpen -> {
                drawArc(tint, 180f, 180f, false, o(8.5f, 4.5f), Size(7f * k, 7f * k), style = st)
                ln(8.5f, 8f, 8.5f, 10.5f)
                if (kind == Ic.LockClosed) ln(15.5f, 8f, 15.5f, 10.5f)
                rr(5.5f, 10.5f, 13f, 10f, 3.6f)
                dot(12f, 15.4f, 1.6f, clear = true)
            }
            Ic.Bulb -> {
                dot(12f, 9.6f, 6.6f)
                rr(9.2f, 13.6f, 5.6f, 4.6f, 1.8f)
                rr(9.8f, 19f, 4.4f, 2.2f, 1.1f)
                // 灯丝高光：镂空小弧
                drawArc(Color.Black, 200f, 80f, false, o(8.6f, 6.2f), Size(5.6f * k, 5.6f * k), style = Stroke(width = 1.5f * k, cap = StrokeCap.Round), blendMode = BlendMode.Clear)
            }
            Ic.Globe -> {
                drawCircle(tint, 8.2f * k, o(12f, 12f), style = st)
                drawOval(tint, o(8.4f, 3.8f), Size(7.2f * k, 16.4f * k), style = Stroke(width = 2f * k, cap = StrokeCap.Round))
                ln(3.9f, 12f, 20.1f, 12f, 2f * k)
            }
            Ic.Send -> { ln(12f, 19f, 12f, 6.2f, 2.9f * k); ln(6.4f, 11.6f, 12f, 6f, 2.9f * k); ln(17.6f, 11.6f, 12f, 6f, 2.9f * k) }
            Ic.Stop -> rr(7f, 7f, 10f, 10f, 2.9f)
            Ic.Sliders -> {
                ln(4.5f, 8f, 19.5f, 8f, 2.4f * k); ln(4.5f, 16f, 19.5f, 16f, 2.4f * k)
                dot(15f, 8f, 4.3f, clear = true); dot(15f, 8f, 2.9f)
                dot(9f, 16f, 4.3f, clear = true); dot(9f, 16f, 2.9f)
            }
            Ic.Search -> { drawCircle(tint, 6f * k, o(10.5f, 10.5f), style = st); ln(15f, 15f, 19.5f, 19.5f, 2.7f * k) }
            Ic.Close -> { ln(6.5f, 6.5f, 17.5f, 17.5f, 2.6f * k); ln(17.5f, 6.5f, 6.5f, 17.5f, 2.6f * k) }
            Ic.ChevronDown -> { ln(6.5f, 9.5f, 12f, 15f, 2.6f * k); ln(17.5f, 9.5f, 12f, 15f, 2.6f * k) }
            Ic.ChevronRight -> { ln(9.5f, 6.5f, 15f, 12f, 2.6f * k); ln(9.5f, 17.5f, 15f, 12f, 2.6f * k) }
            Ic.File -> { rr(5.5f, 3.5f, 13f, 17f, 3.6f, fill = false); ln(9f, 10f, 15f, 10f, 2.1f * k); ln(9f, 14.5f, 13f, 14.5f, 2.1f * k) }
            Ic.Check -> { ln(5.5f, 12.5f, 10f, 17f, 2.8f * k); ln(10f, 17f, 18.5f, 7.5f, 2.8f * k) }
            Ic.Refresh -> {
                val r = 7.2f
                drawArc(tint, -50f, 280f, false, o(12f - r, 12f - r), Size(2 * r * k, 2 * r * k), style = st)
                val a = Math.toRadians(230.0)
                val ex = 12f + r * cos(a).toFloat(); val ey = 12f + r * sin(a).toFloat()
                val tx = -sin(a).toFloat(); val ty = cos(a).toFloat()      // 行进方向
                val nx = cos(a).toFloat(); val ny = sin(a).toFloat()       // 径向
                val head = Path().apply {
                    moveTo((ex + tx * 3.4f) * k, (ey + ty * 3.4f) * k)
                    lineTo((ex + nx * 3.2f) * k, (ey + ny * 3.2f) * k)
                    lineTo((ex - nx * 3.2f) * k, (ey - ny * 3.2f) * k)
                    close()
                }
                drawPath(head, tint)
                drawPath(head, tint, style = Stroke(width = 1.2f * k, join = StrokeJoin.Round))
            }
            Ic.Copy -> {
                rr(4.5f, 4.5f, 11f, 11f, 3.2f, fill = false)
                rr(7.4f, 7.4f, 14.2f, 14.2f, 4.6f, clear = true)
                rr(9f, 9f, 11f, 11f, 3.2f, fill = false)
            }
            Ic.Edit -> rotate(45f, o(12f, 12f)) {
                rr(9.6f, 2.8f, 4.8f, 12.4f, 2.2f, fill = false)
                val tip = Path().apply { moveTo(9.6f * k, 15.2f * k); lineTo(12f * k, 20.6f * k); lineTo(14.4f * k, 15.2f * k) }
                drawPath(tip, tint, style = st)
                ln(9.6f, 7.6f, 14.4f, 7.6f, 2f * k)
            }
            Ic.Pin -> rotate(35f, o(12f, 12f)) {
                val body = Path().apply {
                    moveTo(9.3f * k, 6f * k); lineTo(14.7f * k, 6f * k); lineTo(15.6f * k, 12f * k); lineTo(8.4f * k, 12f * k); close()
                }
                drawPath(body, tint); drawPath(body, tint, style = Stroke(width = 1.6f * k, join = StrokeJoin.Round))
                rr(7.6f, 2.8f, 8.8f, 3.6f, 1.8f)
                ln(6.2f, 12.2f, 17.8f, 12.2f, 2.4f * k)
                ln(12f, 13f, 12f, 20.8f, 2.3f * k)
            }
            Ic.Checklist -> {
                drawCircle(tint, 2.5f * k, o(6.4f, 7.2f), style = st); ln(11.4f, 7.2f, 19.6f, 7.2f, 2.4f * k)
                drawCircle(tint, 2.5f * k, o(6.4f, 16.8f), style = st); ln(11.4f, 16.8f, 19.6f, 16.8f, 2.4f * k)
            }
            Ic.Trash -> {
                rr(6.6f, 7.4f, 10.8f, 13f, 3.4f, fill = false)
                ln(4.6f, 7f, 19.4f, 7f, 2.4f * k)
                rr(9.4f, 3.6f, 5.2f, 3.4f, 1.5f, fill = false)
                ln(10.3f, 11.2f, 10.3f, 16.2f, 2f * k); ln(13.7f, 11.2f, 13.7f, 16.2f, 2f * k)
            }
            Ic.Back -> { ln(19f, 12f, 6f, 12f, 2.7f * k); ln(11.6f, 6.4f, 6f, 12f, 2.7f * k); ln(11.6f, 17.6f, 6f, 12f, 2.7f * k) }
            Ic.Key -> {
                drawCircle(tint, 4f * k, o(8f, 15.4f), style = st)
                ln(10.9f, 12.5f, 19.5f, 3.9f, 2.4f * k)
                ln(16.2f, 7.2f, 18.8f, 9.8f, 2.2f * k)
            }
            Ic.Link -> rotate(-45f, o(12f, 12f)) {
                rr(1.8f, 9f, 11.4f, 6f, 3f, fill = false)
                rr(10.8f, 9f, 11.4f, 6f, 3f, fill = false)
            }
            Ic.Chip -> {
                rr(6.2f, 6.2f, 11.6f, 11.6f, 3.4f, fill = false)
                rr(10f, 10f, 4f, 4f, 1.3f)
                for (t in listOf(9.5f, 14.5f)) {
                    ln(t, 2.8f, t, 6.2f, 1.9f * k); ln(t, 17.8f, t, 21.2f, 1.9f * k)
                    ln(2.8f, t, 6.2f, t, 1.9f * k); ln(17.8f, t, 21.2f, t, 1.9f * k)
                }
            }
            Ic.Font -> {
                ln(3.6f, 19f, 9f, 5.6f, 2.6f * k); ln(14.4f, 19f, 9f, 5.6f, 2.6f * k); ln(5.8f, 14.2f, 12.2f, 14.2f, 2.3f * k)
                drawCircle(tint, 2.6f * k, o(18f, 16.4f), style = Stroke(width = 2.2f * k, cap = StrokeCap.Round))
                ln(20.6f, 13.8f, 20.6f, 19f, 2.2f * k)
            }
            Ic.Chat -> {
                val bubble = Path().apply {
                    moveTo(8.5f * k, 4f * k); lineTo(15.5f * k, 4f * k)
                    quadraticBezierTo(20.5f * k, 4f * k, 20.5f * k, 9f * k); lineTo(20.5f * k, 11f * k)
                    quadraticBezierTo(20.5f * k, 16f * k, 15.5f * k, 16f * k); lineTo(11.5f * k, 16f * k)
                    lineTo(7f * k, 20f * k); lineTo(7.2f * k, 16f * k)
                    quadraticBezierTo(3.5f * k, 15.5f * k, 3.5f * k, 11f * k); lineTo(3.5f * k, 9f * k)
                    quadraticBezierTo(3.5f * k, 4f * k, 8.5f * k, 4f * k); close()
                }
                drawPath(bubble, tint, style = st)
                ln(8.2f, 10f, 15.8f, 10f, 2f * k)
            }
            Ic.Terminal -> {
                rr(2.5f, 4f, 19f, 16f, 5.2f)
                val p = Path().apply { moveTo(7.4f * k, 9.4f * k); lineTo(11f * k, 12f * k); lineTo(7.4f * k, 14.6f * k) }
                drawPath(p, Color.Black, style = Stroke(width = 2.1f * k, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Clear)
                ln(12.8f, 15f, 16.6f, 15f, 2.1f * k, clear = true)
            }
        }
    }
}
