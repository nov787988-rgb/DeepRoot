package com.deeproot.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Store(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    private val file = File(ctx.filesDir, "chats.json")

    fun loadSettings() = Settings(
        sp.getString("key", "") ?: "",
        sp.getString("base", "https://api.deepseek.com") ?: "https://api.deepseek.com",
        // 旧版本把默认提示词（含“每条命令都先确认”的过时规则）存进了本地，这里自动换成新版默认提示词
        (sp.getString("sys", DEFAULT_SYSTEM) ?: DEFAULT_SYSTEM).let { if (it.contains("每条命令都会先经用户确认，被拒绝后")) DEFAULT_SYSTEM else it },
        sp.getString("model", "deepseek-flash") ?: "deepseek-flash",
        (sp.getString("model_options", "deepseek-flash|deepseek-v4-pro") ?: "deepseek-flash|deepseek-v4-pro").split('|').filter { it.isNotBlank() },
        sp.getString("model_cache_fingerprint", "") ?: "",
    )

    fun saveSettings(s: Settings) {
        sp.edit().putString("key", s.apiKey).putString("base", s.baseUrl).putString("sys", s.system).putString("model", s.model).putString("model_options", s.modelOptions.joinToString("|")).putString("model_cache_fingerprint", s.modelCacheFingerprint).apply()
    }

    fun loadToggle(key: String): Boolean = sp.getBoolean(key, false)
    fun saveToggle(key: String, value: Boolean) { sp.edit().putBoolean(key, value).apply() }

    fun loadFont(): String = sp.getString("font", "default") ?: "default"
    fun saveFont(key: String) { sp.edit().putString("font", key).apply() }
    fun loadCustomFont(): Pair<String, String>? {
        val name = sp.getString("font_custom_name", null) ?: return null
        val file = sp.getString("font_custom_file", null) ?: return null
        return name to file
    }
    fun saveCustomFont(name: String, fileName: String) { sp.edit().putString("font_custom_name", name).putString("font_custom_file", fileName).apply() }

    fun loadChats(): List<Chat> = runCatching {
        val a = JSONArray(file.readText())
        (0 until a.length()).map { chatFrom(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun saveChats(l: List<Chat>) {
        runCatching {
            val a = JSONArray()
            l.forEach { a.put(chatTo(it)) }
            file.writeText(a.toString())
        }
    }

    private fun chatTo(c: Chat) = JSONObject().put("id", c.id).put("title", c.title).put("updated", c.updated).put("pinned", c.pinned)
        .put("msgs", JSONArray().also { arr ->
            c.msgs.forEach { m ->
                arr.put(JSONObject().put("role", m.role).put("content", m.content).put("reasoning", m.reasoning).put("progress", m.progress)
                    .put("toolCallId", m.toolCallId ?: JSONObject.NULL).put("denied", m.denied)
                    .put("attachments", JSONArray().also { a -> m.attachments.forEach { a.put(JSONObject().put("uri", it.uri).put("name", it.name).put("mime", it.mime).put("fileId", it.fileId).put("purpose", it.purpose)) } })
                    .put("toolCalls", JSONArray().also { t ->
                        m.toolCalls.forEach { t.put(JSONObject().put("id", it.id).put("name", it.name).put("args", it.args)) }
                    }))
            }
        })

    private fun chatFrom(o: JSONObject): Chat {
        val arr = o.getJSONArray("msgs")
        val msgs = (0 until arr.length()).map { i ->
            val m = arr.getJSONObject(i)
            val t = m.getJSONArray("toolCalls")
            val a = m.optJSONArray("attachments") ?: JSONArray()
            Msg(
                role = m.getString("role"),
                content = m.optString("content"),
                reasoning = m.optString("reasoning"),
                progress = m.optString("progress"),
                toolCalls = (0 until t.length()).map { j -> t.getJSONObject(j).let { ToolCall(it.getString("id"), it.getString("name"), it.getString("args")) } },
                toolCallId = if (m.isNull("toolCallId")) null else m.getString("toolCallId"),
                denied = m.optBoolean("denied"),
                attachments = (0 until a.length()).map { j -> a.getJSONObject(j).let { Attachment(it.getString("uri"), it.getString("name"), it.getString("mime"), it.optString("fileId"), it.optString("purpose")) } },
            )
        }
        return Chat(o.getString("id"), o.getString("title"), msgs, o.optLong("updated"), o.optBoolean("pinned"))
    }
}
