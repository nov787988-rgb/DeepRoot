package com.deeproot.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URI
import java.util.concurrent.TimeUnit

/** DeepSeek 官方 Search & Fetch API。无需 Tavily，也不解析搜索引擎网页 HTML。 */
object WebTools {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private fun apiRoot(base: String): String {
        val root = base.trim().trimEnd('/')
        val uri = runCatching { URI(root) }.getOrNull()
            ?: throw IOException("API Base URL 无效")
        if (uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank()) throw IOException("API Base URL 无效")
        if (!uri.host.equals("api.deepseek.com", true)) {
            throw IOException("官方联网搜索需要 DeepSeek 官方 API 地址（https://api.deepseek.com）；当前地址：${uri.host}")
        }
        return root.removeSuffix("/v1")
    }

    private fun post(base: String, key: String, path: String, body: JSONObject): JSONObject {
        if (key.isBlank()) throw IOException("请先在设置中填写 DeepSeek API Key")
        val url = apiRoot(base) + path
        val req = Request.Builder().url(url)
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(req).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                val message = detail?.takeIf { it.isNotBlank() } ?: raw.take(260)
                throw IOException("DeepSeek ${path.substringAfterLast('/')} HTTP ${response.code}：$message")
            }
            return runCatching { JSONObject(raw) }.getOrElse { throw IOException("DeepSeek 返回了无法解析的数据") }
        }
    }

    suspend fun search(base: String, key: String, query: String): String = withContext(Dispatchers.IO) {
        val q = query.trim().take(128)
        if (q.isEmpty()) return@withContext "错误：搜索关键词不能为空"
        val result = post(base, key, "/v1/tools/search", JSONObject()
            .put("query", q)
            .put("count", 6)
            .put("need_content", false))
        val items = result.optJSONArray("results") ?: JSONArray()
        if (items.length() == 0) return@withContext "没有找到匹配的网页结果。请尝试更具体的关键词。"
        buildString {
            append("后台检索资料（共 ").append(items.length()).append(" 条；仅供综合分析，不要原样展示给用户）：\n")
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                append("\n").append(i + 1).append(". ").append(item.optString("title", "无标题"))
                append("\n[打开来源网页](").append(item.optString("url")).append(")")
                val site = item.optString("site_name")
                if (site.isNotBlank() && site != "null") append("\n网站：").append(site)
                val date = item.optString("date")
                if (date.isNotBlank() && date != "null") append("\n日期：").append(date)
                val summary = item.optString("summary").ifBlank { item.optString("snippet") }
                if (summary.isNotBlank()) append("\n摘要：").append(summary.take(900))
                append('\n')
            }
        }.trim()
    }

    private val privateHost = Regex(
        "^(localhost|.*\\.local|127\\..*|10\\..*|192\\.168\\..*|169\\.254\\..*|172\\.(1[6-9]|2\\d|3[01])\\..*|0\\.0\\.0\\.0|\\[?::1\\]?)$",
        RegexOption.IGNORE_CASE
    )

    suspend fun readUrl(base: String, key: String, url: String): String = withContext(Dispatchers.IO) {
        val value = url.trim()
        val uri = runCatching { URI(value) }.getOrNull()
        val host = uri?.host
        if (uri == null || uri.scheme !in setOf("http", "https") || host.isNullOrBlank() || uri.userInfo != null || value.length > 8192) {
            return@withContext "错误：URL 无效，只支持普通 HTTP/HTTPS 网页链接。"
        }
        if (privateHost.matches(host)) return@withContext "已拦截：不允许读取本机或内网地址。"
        val result = post(base, key, "/v1/tools/fetch", JSONObject().put("url", value))
        val title = result.optString("title").ifBlank { host }
        val content = result.optString("content")
        if (content.isBlank()) return@withContext "网页读取失败：DeepSeek 未返回可提取的正文。"
        "标题：$title\n[打开原网页]($value)\n\n$content".take(16000)
    }
}
