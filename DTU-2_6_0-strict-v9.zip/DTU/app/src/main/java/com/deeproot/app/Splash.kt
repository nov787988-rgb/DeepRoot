package com.deeproot.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

// ───────────────────────── 时间轴（毫秒），想调快慢改这里 ─────────────────────────
private const val BOOT_MS = 500        // 开机日志滚动
private const val CLEAR_MS = 90        // 清屏后的短暂黑场
private const val POP_MS = 520         // DeepTerminal Ultra 逐字浮现
private const val HOLD_MS = 380        // 停留
private const val REMOVE_MS = 900      // 其余字母逐个收拢消失，只留 D T U
private const val SETTLE_MS = 140      // 收拢后的停顿
private const val MOVE_MS = 760        // DTU 飞到聊天界面原位置 + 背景由黑渐变为主题底色
private const val REVEAL_MS = 560      // 其余界面内容渐显

private const val FULL_NAME = "DeepTerminal Ultra"
private val BootGreen = Color(0xFFA6E3A1)
private val DimGray = Color(0xFF7B818B)

/** 开机日志：固定种子生成，每次启动内容一致，约 340 行。 */
private val BOOT_LOG: List<String> by lazy { buildBootLog() }

private fun buildBootLog(): List<String> {
    val r = Random(20261127)
    val out = ArrayList<String>(360)
    var t = 0.0
    fun ts(): String {
        t += r.nextDouble(0.0003, 0.045)
        return String.format(Locale.US, "[%10.6f]", t)
    }
    fun hex(n: Int): String = (0 until n).joinToString("") { "0123456789abcdef"[r.nextInt(16)].toString() }
    fun add(s: String) { out.add(ts() + " " + s) }

    add("Linux version 6.6.30-dtu-android15 (build@dtu-ci) (Android clang version 17.0.2) #1 SMP PREEMPT")
    add("Command line: root=/dev/ram0 ro quiet rootwait androidboot.hardware=dtu androidboot.selinux=enforcing printk.devkmsg=on loglevel=6")
    add("DTU: DeepTerminal Ultra bootloader v2.6 handing over to kernel, uid=0 gid=0")
    repeat(14) { add("BIOS-e820: [mem 0x${hex(16)}-0x${hex(16)}] ${if (it % 5 == 4) "reserved" else "usable"}") }
    add("NX (Execute Disable) protection: active")
    add("efi: EFI v2.8 by DeepTerminal Ultra Firmware, ACPI=0x${hex(8)} SMBIOS3=0x${hex(8)}")
    add("Memory: ${r.nextInt(7_000_000, 7_900_000)}K/${r.nextInt(8_000_000, 8_400_000)}K available (${r.nextInt(14000, 18000)}K kernel code, ${r.nextInt(2000, 4000)}K rwdata)")
    add("SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=8, Nodes=1")
    add("rcu: Hierarchical RCU implementation. RCU restricting CPUs from NR_CPUS=256 to nr_cpu_ids=8.")
    repeat(8) { c -> add("smpboot: CPU$c: Booted secondary processor 0x${hex(6)} [0x${hex(8)}]") }
    val subsystems = listOf(
        "clocksource: Switched to clocksource arch_sys_counter", "NET: Registered PF_INET protocol family",
        "TCP: Hash tables configured (established ${r.nextInt(30000, 90000)} bind ${r.nextInt(30000, 90000)})",
        "NET: Registered PF_UNIX/PF_LOCAL protocol family", "NET: Registered PF_NETLINK protocol family",
        "audit: initializing netlink subsys (disabled)", "cpuidle: using governor menu", "thermal_sys: Registered thermal governor 'step_wise'",
        "iommu: Default domain type: Translated", "vgaarb: loaded", "SCSI subsystem initialized", "usbcore: registered new interface driver usbfs",
        "usbcore: registered new interface driver hub", "pps_core: LinuxPPS API ver. 1 registered", "PTP clock support registered",
        "EDAC MC: Ver: 3.0.0", "Advanced Linux Sound Architecture Driver Initialized.", "Bluetooth: Core ver 2.22",
        "Key type dns_resolver registered", "Loading compiled-in X.509 certificates", "Loaded X.509 cert 'DTU Kernel Signing Key: ${hex(40)}'",
        "selinux: Initializing SELinux 1.0 policy", "SELinux:  policy capability network_peer_controls=1 open_perms=1 extended_socket_class=1",
        "Freeing unused kernel image (initmem) memory: ${r.nextInt(2000, 4000)}K", "Run /init as init process",
    )
    subsystems.forEach { add(it) }
    repeat(46) { i ->
        add("pci 0000:${hex(2)}:${"%02x".format(i % 32)}.${i % 8}: [${hex(4)}:${hex(4)}] type 00 class 0x${hex(6)} PCIe Endpoint, BAR0 [mem 0x${hex(8)}-0x${hex(8)} 64bit pref]")
    }
    repeat(18) { i ->
        add("usb usb${i % 4 + 1}: New USB device found, idVendor=${hex(4)}, idProduct=${hex(4)}, bcdDevice= ${r.nextInt(1, 9)}.${r.nextInt(10, 99)}")
    }
    repeat(22) { i ->
        add("dm-$i: mounted filesystem ${hex(8)}-${hex(4)}-${hex(4)}-${hex(4)}-${hex(12)} r/w with ordered data mode. Quota mode: none.")
    }
    val services = listOf(
        "Create List of Static Device Nodes", "Journal Service", "Load Kernel Modules", "Apply Kernel Variables", "Remount Root and Kernel File Systems",
        "udev Coldplug all Devices", "Rule-based Manager for Device Events and Files", "Network Time Synchronization", "Local File Systems (Pre)",
        "Mount /data", "Mount /storage/emulated", "Mount /dev/pts", "Mount Configuration File System", "Set the console keyboard layout",
        "Network Manager", "Wireless service", "D-Bus System Message Bus", "Permit User Sessions", "SELinux Policy Loader", "Cryptographic Setup for dtu-store",
        "DTU Encrypted Preferences", "DTU Root Shell Bridge", "DTU Model Registry", "DTU API Relay Endpoint Resolver", "DTU Streaming Parser",
        "DTU Attachment Extractor", "DTU Chat Store", "DTU Command Guard", "DTU Markdown Renderer", "DTU Web Tools",
    )
    var round = 0
    while (out.size < 340) {
        val s = services[round % services.size]
        if (round % 7 == 3) add("systemd[1]: Starting $s...") else add("[  OK  ] Started $s.")
        if (round % 11 == 5) add("dtu-init[${r.nextInt(100, 4000)}]: ${listOf("probing", "mounting", "verifying", "loading")[r.nextInt(4)]} /dev/block/dm-${r.nextInt(0, 30)} flags=0x${hex(4)} digest=${hex(32)}")
        round++
    }
    add("dtu: root shell ready (uid=0), command guard armed, encrypted store unlocked")
    add("dtu: welcome to DeepTerminal Ultra")
    return out
}

private fun stagger(p: Float, i: Int, n: Int, spread: Float = 0.62f): Float {
    val d = spread * i / (n - 1).coerceAtLeast(1)
    return FastOutSlowInEasing.transform(((p - d) / (1f - spread)).coerceIn(0f, 1f))
}

/**
 * 启动动画：开机日志(0.5s) → 清屏 → DeepTerminal Ultra 浮现 → 其余字母收拢消失只剩 DTU →
 * DTU 移动到聊天首页标题的位置（同时背景由黑渐变为主题底色）→ 其余界面渐显。
 * [target] 返回首页 “DTU” 标题在窗口中的位置；[onFinished] 在动画结束后调用，调用方此时应显示真实标题并移除本层。
 */
@Composable
fun SplashOverlay(target: () -> Rect?, onFinished: () -> Unit) {
    val boot = remember { Animatable(0f) }
    val pop = remember { Animatable(0f) }
    val collapse = remember { Animatable(0f) }
    val move = remember { Animatable(0f) }
    val reveal = remember { Animatable(0f) }
    var phase by remember { mutableIntStateOf(0) } // 0 = 开机日志, 1 = 品牌字样

    LaunchedEffect(Unit) {
        boot.animateTo(1f, tween(BOOT_MS, easing = LinearEasing))
        phase = 1
        delay(CLEAR_MS.toLong())
        pop.animateTo(1f, tween(POP_MS, easing = LinearEasing))
        delay(HOLD_MS.toLong())
        collapse.animateTo(1f, tween(REMOVE_MS, easing = LinearEasing))
        delay(SETTLE_MS.toLong())
        withTimeoutOrNull(1500) { snapshotFlow { target() }.first { it != null } }
        move.animateTo(1f, tween(MOVE_MS, easing = FastOutSlowInEasing))
        reveal.animateTo(1f, tween(REVEAL_MS, easing = FastOutSlowInEasing))
        onFinished()
    }

    val appBg = MaterialTheme.colorScheme.background
    val appInk = MaterialTheme.colorScheme.onBackground
    val density = LocalDensity.current
    val brandStyle = LocalTextStyle.current.merge(TextStyle(fontSize = 30.sp, fontWeight = FontWeight.SemiBold))
    val measurer = rememberTextMeasurer()
    val fullWidthPx = remember(brandStyle, density) { measurer.measure(FULL_NAME, brandStyle).size.width.toFloat() }

    BoxWithConstraints(
        Modifier.fillMaxSize()
            // 背景：黑 → 主题底色（移动阶段），随后整体淡出，露出下方已就位的聊天界面
            .background(lerp(Color.Black, appBg, move.value).copy(alpha = 1f - reveal.value))
            // 动画期间吞掉所有触摸，避免误触下面的界面
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()

        if (phase == 0) {
            val lineH = with(density) { 11.sp.toPx() }
            val visibleLines = ((h / lineH).toInt() + 1).coerceAtLeast(1)
            val count = (BOOT_LOG.size * boot.value).toInt().coerceIn(1, BOOT_LOG.size)
            val text = remember(count, visibleLines) {
                BOOT_LOG.subList((count - visibleLines).coerceAtLeast(0), count).joinToString("\n")
            }
            Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars).padding(horizontal = 6.dp)) {
                Text(
                    text, color = BootGreen, softWrap = false, overflow = TextOverflow.Clip,
                    style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 11.sp)
                )
            }
        } else {
            val s0 = if (fullWidthPx > 0f) minOf(1f, w * 0.86f / fullWidthPx) else 1f
            val scale = s0 + (1f - s0) * move.value
            val rect = target()
            val dx = if (rect != null) (rect.center.x - w / 2f) * move.value else 0f
            val dy = if (rect != null) (rect.center.y - h / 2f) * move.value else 0f
            val keepColor = lerp(Color.White, appInk, move.value)

            Row(
                Modifier.align(Alignment.Center)
                    .wrapContentWidth(Alignment.CenterHorizontally, unbounded = true)
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = dx; translationY = dy },
                verticalAlignment = Alignment.CenterVertically
            ) {
                FULL_NAME.forEachIndexed { i, ch ->
                    val keep = ch.isUpperCase()
                    val a = stagger(pop.value, i, FULL_NAME.length)
                    val r = if (keep) 0f else stagger(collapse.value, i, FULL_NAME.length)
                    Text(
                        ch.toString(), fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
                        color = if (keep) keepColor else DimGray, softWrap = false,
                        modifier = Modifier
                            .layout { m, c ->
                                val p = m.measure(c)
                                val lw = (p.width * (1f - r)).roundToInt()
                                layout(lw, p.height) { p.placeRelative(0, 0) }
                            }
                            .graphicsLayer {
                                alpha = a * (1f - r)
                                translationY = (1f - a) * 14.dp.toPx()
                                scaleX = 1f - 0.5f * r
                            }
                    )
                }
            }
        }
    }
}
