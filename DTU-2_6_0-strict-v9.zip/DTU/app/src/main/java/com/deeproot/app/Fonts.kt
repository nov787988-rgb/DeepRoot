package com.deeproot.app

import android.graphics.Typeface
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import java.io.File

/** 当前字体选择：key 为预设名或 "custom"（用户导入的字体文件） */
data class AppFontSpec(val key: String = "default", val customPath: String? = null)

val LocalAppFont = compositionLocalOf { AppFontSpec() }

class FontPreset(val key: String, val label: String, val hint: String)

val FONT_PRESETS = listOf(
    FontPreset("default", "默认", "界面系统体 · 回答衬线"),
    FontPreset("serif", "衬线", "典雅书卷感"),
    FontPreset("mono", "等宽", "终端代码感"),
    FontPreset("cursive", "手写", "圆润手写感"),
    FontPreset("condensed", "窄体", "紧凑利落"),
    FontPreset("light", "纤细", "轻盈通透"),
    FontPreset("casual", "随性", "轻松随和"),
)

private fun platformName(key: String): String? = when (key) {
    "condensed" -> "sans-serif-condensed"
    "light" -> "sans-serif-light"
    "casual" -> "casual"
    else -> null
}

/** Compose 用字体族；null 表示沿用系统默认 */
fun fontFamilyOf(spec: AppFontSpec): FontFamily? = runCatching {
    when (spec.key) {
        "default" -> null
        "serif" -> FontFamily.Serif
        "mono" -> FontFamily.Monospace
        "cursive" -> FontFamily.Cursive
        "custom" -> spec.customPath?.let { p -> File(p).takeIf { it.exists() }?.let { FontFamily(Font(it)) } }
        else -> platformName(spec.key)?.let { FontFamily(Typeface.create(it, Typeface.NORMAL)) }
    }
}.getOrNull()

/** 设置页预览用：默认项也要返回明确的系统字体，避免预览跟着当前字体变 */
fun previewFamilyOf(spec: AppFontSpec): FontFamily = fontFamilyOf(spec) ?: FontFamily.Default

/** Markdown（TextView）用字体：默认项保持原有的衬线回答风格 */
fun typefaceOf(spec: AppFontSpec): Typeface = runCatching {
    when (spec.key) {
        "default" -> Typeface.create("serif", Typeface.NORMAL)
        "serif" -> Typeface.SERIF
        "mono" -> Typeface.MONOSPACE
        "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
        "custom" -> Typeface.createFromFile(spec.customPath ?: error("no font"))
        else -> Typeface.create(platformName(spec.key), Typeface.NORMAL)
    }
}.getOrElse { Typeface.create("serif", Typeface.NORMAL) }
