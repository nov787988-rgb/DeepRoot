package com.deeproot.app

import org.json.JSONArray
import org.json.JSONObject

data class ToolCall(val id: String, val name: String, val args: String)

data class Attachment(val uri: String, val name: String, val mime: String, val fileId: String = "", val purpose: String = "")

data class Msg(
    val role: String,                       // user | assistant | tool
    val content: String = "",
    val reasoning: String = "",             // 内部推理数据，仅用于 API 连续调用，不展示给用户
    val progress: String = "",              // 面向用户的简短工作提要
    val toolCalls: List<ToolCall> = emptyList(),
    val toolCallId: String? = null,         // role=tool 时对应的调用 id
    val denied: Boolean = false,            // 用户是否拒绝执行
    val attachments: List<Attachment> = emptyList(),
)

data class Chat(val id: String, val title: String, val msgs: List<Msg>, val updated: Long)

data class Pending(val callId: String, val command: String, val reason: String, val dangerous: Boolean)

data class Settings(
    val apiKey: String = "",
    val baseUrl: String = "https://api.deepseek.com",
    val system: String = DEFAULT_SYSTEM,
    val model: String = "deepseek-flash",
    val modelOptions: List<String> = listOf("deepseek-flash", "deepseek-v4-pro"),
    val modelCacheFingerprint: String = "",
)

const val DEFAULT_SYSTEM =
    "你是运行在用户 Android 手机上的助手。需要查看或修改系统时，调用 run_shell 工具执行 shell 命令（root 权限）。" +
    "规则：1) 每次只执行一条命令；2) 优先使用只读命令；3) 破坏性命令（删除、格式化、写分区等）必须先向用户说明风险；" +
    "4) 严格模式开启时每条命令都会先经用户确认，关闭时只读命令会直接执行、其余命令仍需用户确认，被拒绝后不要重复请求同一命令；5) 根据命令输出继续分析并用中文回答。"

/** 暴露给模型的唯一工具：执行 shell 命令（只读命令直接执行，其余命令需用户批准（严格模式下全部需要批准）） */
val TOOLS: JSONArray = JSONArray().put(
    JSONObject()
        .put("type", "function")
        .put(
            "function", JSONObject()
                .put("name", "run_shell")
                .put("description", "在用户手机上以 root 身份执行一条 shell 命令并返回输出。非只读命令会先经用户确认。")
                .put(
                    "parameters", JSONObject()
                        .put("type", "object")
                        .put(
                            "properties", JSONObject()
                                .put("command", JSONObject().put("type", "string").put("description", "要执行的 shell 命令"))
                                .put("reason", JSONObject().put("type", "string").put("description", "用一句话向用户解释为什么要执行"))
                        )
                        .put("required", JSONArray().put("command").put("reason"))
                )
        )
)


private fun fnTool(name: String, desc: String, param: String, paramDesc: String) = JSONObject()
    .put("type", "function")
    .put(
        "function", JSONObject().put("name", name).put("description", desc)
            .put(
                "parameters", JSONObject().put("type", "object")
                    .put("properties", JSONObject().put(param, JSONObject().put("type", "string").put("description", paramDesc)))
                    .put("required", JSONArray().put(param))
            )
    )

/** 联网开关打开时额外提供的工具：由 App 本地执行，不需要用户逐条确认 */
val WEB_TOOLS: JSONArray = JSONArray()
    .put(fnTool("web_search", "在后台检索最新网页资料供你综合回答；不要向用户展示检索过程或搜索结果清单。涉及最新信息、价格、版本、新闻、当前事实或用户明确要求搜索时必须使用。", "query", "搜索关键词"))
    .put(fnTool("read_url", "在后台读取指定 HTTP/HTTPS 网页正文供你核实事实；不要向用户展示网页抓取过程或原始正文。搜索资料不足或需要核实原文时使用。", "url", "完整的 http/https 链接"))

private val DANGEROUS = listOf(
    Regex("""\brm\s+(-[a-zA-Z]*\s+)*(/|/\*|/data|/system|/sdcard|/storage|${'$'}HOME|~)(\s|$)"""),
    Regex("""\bdd\s+.*\bof=/dev/"""),
    Regex("""\bmkfs"""), Regex("""\bwipe\b"""), Regex("""\bformat\b"""),
    Regex(""">\s*/dev/block"""), Regex("""\b(reboot|poweroff)\b"""),
    Regex("""\bsetprop\b"""), Regex("""\bresetprop\b"""),
    Regex("""\bpm\s+(uninstall|clear|disable)"""), Regex("""\bchmod\s+(-R\s+)?777\s+/"""),
    Regex("""\bfastboot\b"""), Regex("""\bflash\b"""), Regex("""\bmount\b.*\b(rw|remount)\b"""),
)

fun isDangerous(cmd: String) = DANGEROUS.any { it.containsMatchIn(cmd) }


/** 只读命令白名单（非严格模式下，这类命令无需确认直接执行） */
private val READ_ONLY_CMDS = setOf(
    "ls", "cat", "head", "tail", "wc", "stat", "file", "pwd", "echo", "printf", "date", "id", "whoami", "uname",
    "df", "du", "ps", "top", "uptime", "free", "env", "printenv", "getprop", "dumpsys", "getenforce", "lsmod",
    "grep", "egrep", "fgrep", "sort", "uniq", "cut", "tr", "basename", "dirname", "readlink", "realpath", "which",
    "md5sum", "sha1sum", "sha256sum", "lsof", "netstat", "ss", "ifconfig", "ip", "logcat", "pidof", "hostname",
    "find", "sed", "awk", "settings", "pm", "cmd", "am", "wm", "service", "test", "[", "true", "stat", "ping", "nproc", "cal"
)
private val SEGMENT_SPLIT = Regex("""\|\||&&|[|;&\n]""")
private val WRITE_META = Regex("""[<>`]|\$\(""")

private fun segmentReadOnly(seg: String): Boolean {
    val t = seg.trim()
    if (t.isEmpty()) return true
    val words = t.split(Regex("\\s+")).dropWhile { Regex("^[A-Za-z_][A-Za-z0-9_]*=.*").matches(it) }
    val head = words.firstOrNull()?.substringAfterLast('/') ?: return true
    if (head !in READ_ONLY_CMDS) return false
    val rest = words.drop(1)
    return when (head) {
        "find" -> rest.none { it in setOf("-delete", "-exec", "-execdir", "-ok", "-okdir", "-fprint", "-fprintf", "-fls") }
        "sed" -> rest.none { it.startsWith("-i") || it == "--in-place" || it.contains("w ") }
        "awk" -> rest.none { it.contains("system(") || it.contains("print >") }
        "settings" -> rest.firstOrNull() in setOf("get", "list")
        "pm" -> rest.firstOrNull() in setOf("list", "path", "dump", "get-install-location")
        "am" -> rest.firstOrNull() in setOf("stack", "get-config", "get-current-user")
        "wm" -> rest.firstOrNull() in setOf("size", "density") && rest.drop(1).none { it.isNotBlank() && !it.startsWith("-") }
        "cmd" -> rest.firstOrNull() in setOf("package", "activity", "window", "battery", "connectivity", "wifi") &&
            rest.getOrNull(1) in setOf("list", "dump", "get", "resolve-activity", "path", "status", "stack")
        "service" -> rest.firstOrNull() in setOf("list", "check")
        "ip" -> rest.firstOrNull() in setOf("addr", "address", "route", "link", "neigh", "a", "r") && rest.none { it in setOf("add", "del", "delete", "flush", "set") }
        "top" -> rest.contains("-n") || rest.contains("-b")
        "env" -> rest.isEmpty()
        else -> true
    }
}

/** 判断一条命令是否只读：无重定向/命令替换，且每个管道、分号分段都只读，同时不含高风险模式 */
fun isReadOnly(cmd: String): Boolean {
    if (cmd.isBlank() || isDangerous(cmd)) return false
    if (WRITE_META.containsMatchIn(cmd)) return false
    return cmd.split(SEGMENT_SPLIT).all { segmentReadOnly(it) }
}
