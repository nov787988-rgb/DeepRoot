package com.deeproot.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel

val Brand = Color(0xFF2868D7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(
                    primary = Color(0xFF82B1FF),
                    secondary = Color(0xFF9CC3FF),
                    surface = Color(0xFF101318),
                    background = Color(0xFF101318)
                ) else lightColorScheme(
                    primary = Brand,
                    secondary = Color(0xFF4C83D8),
                    surface = Color(0xFFFCFCFD),
                    background = Color(0xFFFCFCFD)
                )
            ) {
                val vm: ChatViewModel = viewModel()
                App(vm)
            }
        }
    }
}
