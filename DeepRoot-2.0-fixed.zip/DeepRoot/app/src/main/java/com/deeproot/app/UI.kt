package com.deeproot.app

import android.widget.TextView
import androidx.compose.foundation.clickable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: ChatViewModel) {
    val chats by vm.chats.collectAsState()
    val cur by vm.currentId.collectAsState()
    val busy by vm.busy.collectAsState()
    val pending by vm.pending.collectAsState()
    val deep by vm.deepThink.collectAsState()
    val err by vm.error.collectAsState()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var showSettings by remember { mutableStateOf(false) }
    val chat = chats.find { it.id == cur }

    LaunchedEffect(err) { err?.let { snack.showSnackbar(it); vm.error.value = null } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.fillMaxHeight().padding(12.dp)) {
                    Text("DeepRoot", fontSize = 25.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = Brand, modifier = Modifier.padding(start = 8.dp, top = 14.dp, bottom = 18.dp))
                    Button(onClick = { vm.newChat(); scope.launch { drawer.close() } }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("＋  开启新对话") }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(chats, key = { it.id }) { c ->
                            Row(Modifier.fillMaxWidth().clickable { vm.select(c.id); scope.launch { drawer.close() } }.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Surface(color = if (c.id == cur) Brand.copy(alpha = .09f) else Color.Transparent, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
                                    Text(c.title, Modifier.padding(12.dp), maxLines = 1,
                                        color = if (c.id == cur) Brand else MaterialTheme.colorScheme.onSurface)
                                }
                                TextButton(onClick = { vm.delete(c.id) }) { Text("删除") }
                            }
                        }
                    }
                    TextButton(onClick = { showSettings = true; scope.launch { drawer.close() } }) { Text("⚙ 设置") }
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(
                    title = { Column { Text("DeepRoot", maxLines = 1, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold); if (chat != null) Text(chat.title, maxLines = 1, fontSize = 11.sp, color = MaterialTheme.colorScheme.outline) } },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawer.open() } }) { Text("☰", fontSize = 21.sp) } },
                    actions = { IconButton(onClick = { vm.newChat() }) { Text("＋", fontSize = 25.sp, color = Brand) } },
                )
            },
            bottomBar = {
                var text by remember { mutableStateOf("") }
                Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp, modifier = Modifier.imePadding()) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 7.dp)) { FilterChip(selected = deep, onClick = { vm.deepThink.value = !deep }, label = { Text(if (deep) "深度思考已开启" else "深度思考 R1") }, shape = RoundedCornerShape(50.dp)) }
                        Row(verticalAlignment = Alignment.Bottom) {
                            OutlinedTextField(
                                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                                placeholder = { Text("向 DeepRoot 发送消息…") }, maxLines = 5, shape = RoundedCornerShape(24.dp),
                                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant),
                            )
                            Spacer(Modifier.width(8.dp))
                            if (busy) Button(onClick = { vm.stop() }, shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)) { Text("■") }
                            else Button(onClick = { vm.send(text); text = "" }, enabled = text.isNotBlank(), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)) { Text("↑", fontSize = 24.sp) }
                        }
                    }
                }
            },
        ) { pad ->
            val msgs = chat?.msgs.orEmpty()
            val results = remember(msgs) { msgs.filter { it.role == "tool" }.associateBy { it.toolCallId ?: "" } }
            val shown = msgs.filter { it.role != "tool" }
            val state = rememberLazyListState()
            LaunchedEffect(msgs.size, msgs.lastOrNull()?.content?.length, msgs.lastOrNull()?.reasoning?.length) {
                if (shown.isNotEmpty()) state.scrollToItem(shown.size - 1)
            }
            if (shown.isEmpty()) {
                Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(28.dp)) {
                        Surface(color = Brand.copy(alpha = .10f), shape = RoundedCornerShape(26.dp), modifier = Modifier.size(76.dp), tonalElevation = 0.dp) {
                            Box(contentAlignment = Alignment.Center) { Text("D", color = Brand, fontSize = 42.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
                        }
                        Text("你好，我是 DeepRoot", color = MaterialTheme.colorScheme.onSurface, fontSize = 23.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                        Text("今天有什么可以帮你？", color = MaterialTheme.colorScheme.outline, fontSize = 14.sp)
                        Text("智能对话  ·  深度思考  ·  Root 助手", color = Brand, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(Modifier.padding(pad).fillMaxSize(), state = state, contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(shown.size) { i ->
                        val m = shown[i]
                        AnimatedVisibility(visible = true, enter = fadeIn(tween(220)) + slideInVertically(initialOffsetY = { it / 12 }, animationSpec = tween(220))) {
                            MsgItem(m, results, isLast = i == shown.lastIndex, busy = busy, onRegen = { vm.regenerate() })
                        }
                    }
                }
            }
        }
    }

    pending?.let { ApproveDialog(it) { ok -> vm.approve(ok) } }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun MsgItem(m: Msg, results: Map<String, Msg>, isLast: Boolean, busy: Boolean, onRegen: () -> Unit) {
    if (m.role == "user") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f), shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 5.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                Text(m.content, Modifier.padding(horizontal = 15.dp, vertical = 11.dp), lineHeight = 23.sp)
            }
        }
        return
    }
    Column(Modifier.fillMaxWidth().padding(end = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 7.dp)) {
            Surface(color = Brand.copy(alpha = .10f), shape = RoundedCornerShape(8.dp), modifier = Modifier.size(25.dp)) { Box(contentAlignment = Alignment.Center) { Text("D", color = Brand, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) } }
            Text("  DeepRoot", fontSize = 12.sp, color = Brand, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        }
        if (m.reasoning.isNotEmpty()) {
            var open by remember { mutableStateOf(false) }
            Text(if (open) "▾ 思考过程" else "▸ 思考过程", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp,
                modifier = Modifier.clickable { open = !open })
            if (open) Text(m.reasoning, fontSize = 13.sp, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(start = 8.dp, top = 4.dp))
            Spacer(Modifier.height(6.dp))
        }
        if (m.content.isNotEmpty()) Markdown(m.content)
        m.toolCalls.forEach { tc -> ToolCard(tc, results[tc.id]) }
        if (m.content.isEmpty() && m.reasoning.isEmpty() && m.toolCalls.isEmpty() && busy && isLast)
            TypingIndicator()
        if (isLast && !busy && m.content.isNotEmpty()) {
            val clip = LocalClipboardManager.current
            Row {
                TextButton(onClick = { clip.setText(AnnotatedString(m.content)) }) { Text("复制", fontSize = 12.sp) }
                TextButton(onClick = onRegen) { Text("重新生成", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
fun Markdown(text: String) {
    val ctx = LocalContext.current
    val markwon = remember { Markwon.create(ctx) }
    val color = MaterialTheme.colorScheme.onSurface.toArgb()
    AndroidView(
        factory = { TextView(it).apply { textSize = 15f; setTextIsSelectable(true) } },
        update = { it.setTextColor(color); markwon.setMarkdown(it, text) },
    )
}

@Composable
fun ToolCard(tc: ToolCall, result: Msg?) {
    val args = runCatching { org.json.JSONObject(tc.args) }.getOrNull()
    val cmd = args?.optString("command").orEmpty()
    val why = args?.optString("reason").orEmpty()
    var expand by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text("⚡ 终端命令", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            if (why.isNotBlank()) Text(why, fontSize = 13.sp)
            Text("$ $cmd", fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
            when {
                result == null -> Text("等待确认 / 执行中…", fontSize = 12.sp, color = Brand)
                result.denied -> Text("✕ 未执行（${result.content}）", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                else -> {
                    Text(if (expand) "▾ 输出" else "▸ 输出（点击展开）", fontSize = 12.sp, color = Brand, modifier = Modifier.clickable { expand = !expand })
                    if (expand) Text(result.content, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                        modifier = Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState()))
                }
            }
        }
    }
}

@Composable
fun ApproveDialog(p: Pending, onDecide: (Boolean) -> Unit) {
    AlertDialog(
        onDismissRequest = {},   // 必须明确选择，点击外部不会放行
        title = { Text(if (p.dangerous) "⚠️ 高危命令，请仔细确认" else "允许执行终端命令？") },
        text = {
            Column {
                if (p.reason.isNotBlank()) Text("原因：${p.reason}")
                Spacer(Modifier.height(8.dp))
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                    Text(p.command, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                        modifier = Modifier.padding(8.dp).heightIn(max = 200.dp).verticalScroll(rememberScrollState()))
                }
                Spacer(Modifier.height(8.dp))
                Text("将以 root 身份执行，仅本次有效。", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                if (p.dangerous) Text("该命令可能造成数据丢失或系统无法启动。", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(onClick = { onDecide(true) },
                colors = if (p.dangerous) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.buttonColors()
            ) { Text(if (p.dangerous) "仍然执行" else "允许执行") }
        },
        dismissButton = { TextButton(onClick = { onDecide(false) }) { Text("拒绝") } },
    )
}

@Composable
fun SettingsDialog(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings.collectAsState().value
    val root by vm.rootState.collectAsState()
    var key by remember { mutableStateOf(s.apiKey) }
    var base by remember { mutableStateOf(s.baseUrl) }
    var sys by remember { mutableStateOf(s.system) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("设置") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions.Default)
                OutlinedTextField(base, { base = it }, label = { Text("Base URL") }, singleLine = true)
                OutlinedTextField(sys, { sys = it }, label = { Text("系统提示词") }, maxLines = 6)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Root：" + when (root) { true -> "已授予"; false -> "未授予"; null -> "未检测" }, Modifier.weight(1f))
                    OutlinedButton(onClick = { vm.checkRoot() }) { Text("检测 / 授予") }
                }
                Text("即使已授予 root，每条命令仍需你逐条确认。", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            }
        },
        confirmButton = { Button(onClick = { vm.saveSettings(Settings(key.trim(), base.trim(), sys)); onClose() }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onClose) { Text("取消") } },
    )
}

@Composable
fun TypingIndicator() {
    val transition = rememberInfiniteTransition(label = "typing")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
        repeat(3) { i ->
            val alpha by transition.animateFloat(initialValue = .25f, targetValue = 1f, animationSpec = infiniteRepeatable(animation = tween(480, delayMillis = i * 140, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse), label = "dot$i")
            Box(Modifier.size(7.dp).then(Modifier), contentAlignment = Alignment.Center) { Surface(color = Brand.copy(alpha = alpha), shape = RoundedCornerShape(50), modifier = Modifier.fillMaxSize()) {} }
        }
        Text("正在思考", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
    }
}
