# DeepRoot

DeepSeek 风格的 Android 对话 App：直接调用 DeepSeek API（OpenAI 兼容），
模型可通过 `run_shell` 工具请求执行终端命令；获得 root 后，**每条命令都会弹窗询问，用户同意才执行**。

## 功能
- 流式对话 / Markdown 渲染 / 深度思考开关（deepseek-reasoner，思考过程可折叠）
- 多会话历史（本地 JSON）、新对话、删除、复制、重新生成、停止生成
- Function Calling：run_shell → 确认弹窗 → libsu(su) 执行 → 输出回传模型继续分析
- 高危命令（rm -rf /、dd of=/dev、mkfs、setprop、reboot 等）红色警示
- API Key 用 EncryptedSharedPreferences 加密存储

## 构建
Android Studio (Koala+) 打开本目录 → Sync → Run。minSdk 26 / JDK 17。
首次运行：设置里填 API Key → 点「检测/授予」，在 KernelSU/Magisk 里允许 su。

## 安全设计
- 命令执行唯一入口是 ChatViewModel.agentLoop 中的 `d.await()`，没有"始终允许"
- 弹窗点击外部不会放行；停止/异常时自动补齐未应答的 tool_call
- 30 秒超时，输出截断 8000 字符

## 固定签名

此项目已内置 DeepRoot 专用固定签名密钥，GitHub Actions 会直接生成可更新安装的签名 Release APK。

**重要：请将 GitHub 仓库保持为 Private（私有）**。不要公开上传此项目或分享 `app/deeproot-release.jks`，否则他人可能获得该应用的签名能力。请永久保留此密钥；以后所有更新版本必须继续使用同一密钥，否则 Android 将无法覆盖安装。

## DeepRoot 2.1.0 UI/API update

- Reworked the app palette to blue, white and near-black.
- Added floating rounded header controls and a glass-like rounded composer surface.
- Changed Root approvals from a modal dialog to inline command cards in the conversation.
- Command cards now show pending, rejected, successful and failed states, with collapsible output.
- Added model selection in Settings (`deepseek-chat`, `deepseek-reasoner`, `deepseek-flash`).
- Added DeepSeek server-side web search and URL-reading tools when Smart Search is enabled. Search uses `deepseek-flash` as required by the current DeepSeek API guide.
- Added smooth message entrance and compact history separators.

Attachment parsing for documents/images and video handling are not included in this pass yet; they require the DeepSeek Files API upload/reference flow and a separate video-processing path.
