package com.deeproot.app

import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object RootShell {
    /** 首次调用会触发 su 授权弹窗（Magisk / KernelSU / APatch 均可） */
    suspend fun isRoot(): Boolean = withContext(Dispatchers.IO) { Shell.getShell().isRoot }

    private fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** 仅在用户批准后调用。30 秒超时，输出截断到 8000 字符。 */
    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        if (!Shell.getShell().isRoot) return@withContext "错误：尚未获得 root 权限"
        val r = Shell.cmd("timeout 30 sh -c " + quote(cmd)).exec()
        val out = r.out.joinToString("\n").take(8000)
        val err = r.err.joinToString("\n").take(2000)
        buildString {
            append("exit=").append(r.code)
            if (out.isNotEmpty()) append("\n[stdout]\n").append(out)
            if (err.isNotEmpty()) append("\n[stderr]\n").append(err)
        }
    }
}
