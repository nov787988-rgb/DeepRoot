package com.deeproot.app

import android.widget.TextView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: ChatViewModel) {
    val chats by vm.chats.collectAsState()
    val cur by vm.currentId.collectAsState()
    val busy by vm.busy.collectAsState()
    val pending by vm.pending.collectAsState()
    val deep by vm.deepThink.collectAsState()
    val err by vm.error.collectAsState()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var showSettings by remember { mutableStateOf(false) }
    val chat = chats.find { it.id == cur }

    LaunchedEffect(err) { err?.let { snack.showSnackbar(it); vm.error.value = null } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.fillMaxHeight().padding(12.dp)) {
                    Button(onClick = { vm.newChat(); scope.launch { drawer.close() } }, modifier = Modifier.fillMaxWidth()) { Text("＋ 开启新对话") }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(chats, key = { it.id }) { c ->
                            Row(Modifier.fillMaxWidth().clickable { vm.select(c.id); scope.launch { drawer.close() } }.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(c.title, Modifier.weight(1f).padding(8.dp), maxLines = 1,
                                    color = if (c.id == cur) Brand else MaterialTheme.colorScheme.onSurface)
                                TextButton(onClick = { vm.delete(c.id) }) { Text("删除") }
                            }
                        }
                    }
                    TextButton(onClick = { showSettings = true; scope.launch { drawer.close() } }) { Text("⚙ 设置") }
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(
                    title = { Text(chat?.title ?: "DeepRoot", maxLines = 1) },
                    navigationIcon = { TextButton(onClick = { scope.launch { drawer.open() } }) { Text("☰", fontSize = 20.sp) } },
                    actions = { TextButton(onClick = { vm.newChat() }) { Text("＋", fontSize = 20.sp) } },
                )
            },
            bottomBar = {
                var text by remember { mutableStateOf("") }
                Surface(tonalElevation = 3.dp, modifier = Modifier.imePadding()) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row { FilterChip(selected = deep, onClick = { vm.deepThink.value = !deep }, label = { Text("深度思考 (R1)") }) }
                        Row(verticalAlignment = Alignment.Bottom) {
                            OutlinedTextField(
                                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                                placeholder = { Text("给 DeepRoot 发送消息") }, maxLines = 5, shape = RoundedCornerShape(20.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            if (busy) Button(onClick = { vm.stop() }) { Text("■") }
                            else Button(onClick = { vm.send(text); text = "" }, enabled = text.isNotBlank()) { Text("↑") }
                        }
                    }
                }
            },
        ) { pad ->
            val msgs = chat?.msgs.orEmpty()
            val results = remember(msgs) { msgs.filter { it.role == "tool" }.associateBy { it.toolCallId ?: "" } }
            val shown = msgs.filter { it.role != "tool" }
            val state = rememberLazyListState()
            LaunchedEffect(msgs.size, msgs.lastOrNull()?.content?.length, msgs.lastOrNull()?.reasoning?.length) {
                if (shown.isNotEmpty()) state.scrollToItem(shown.size - 1)
            }
            if (shown.isEmpty()) {
                Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("今天有什么可以帮到你？", color = Brand, fontSize = 20.sp)
                }
            } else {
                LazyColumn(Modifier.padding(pad).fillMaxSize(), state = state, contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(shown.size) { i ->
                        val m = shown[i]
                        MsgItem(m, results, isLast = i == shown.lastIndex, busy = busy, onRegen = { vm.regenerate() })
                    }
                }
            }
        }
    }

    pending?.let { ApproveDialog(it) { ok -> vm.approve(ok) } }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun MsgItem(m: Msg, results: Map<String, Msg>, isLast: Boolean, busy: Boolean, onRegen: () -> Unit) {
    if (m.role == "user") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                Text(m.content, Modifier.padding(12.dp))
            }
        }
        return
    }
    Column(Modifier.fillMaxWidth()) {
        if (m.reasoning.isNotEmpty()) {
            var open by remember { mutableStateOf(false) }
            Text(if (open) "▾ 思考过程" else "▸ 思考过程", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp,
                modifier = Modifier.clickable { open = !open })
            if (open) Text(m.reasoning, fontSize = 13.sp, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(start = 8.dp, top = 4.dp))
            Spacer(Modifier.height(6.dp))
        }
        if (m.content.isNotEmpty()) Markdown(m.content)
        m.toolCalls.forEach { tc -> ToolCard(tc, results[tc.id]) }
        if (m.content.isEmpty() && m.reasoning.isEmpty() && m.toolCalls.isEmpty() && busy && isLast)
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        if (isLast && !busy && m.content.isNotEmpty()) {
            val clip = LocalClipboardManager.current
            Row {
                TextButton(onClick = { clip.setText(AnnotatedString(m.content)) }) { Text("复制", fontSize = 12.sp) }
                TextButton(onClick = onRegen) { Text("重新生成", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
fun Markdown(text: String) {
    val ctx = LocalContext.current
    val markwon = remember { Markwon.create(ctx) }
    val color = MaterialTheme.colorScheme.onSurface.toArgb()
    AndroidView(
        factory = { TextView(it).apply { textSize = 15f; setTextIsSelectable(true) } },
        update = { it.setTextColor(color); markwon.setMarkdown(it, text) },
    )
}

@Composable
fun ToolCard(tc: ToolCall, result: Msg?) {
    val args = runCatching { org.json.JSONObject(tc.args) }.getOrNull()
    val cmd = args?.optString("command").orEmpty()
    val why = args?.optString("reason").orEmpty()
    var expand by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text("⚡ 终端命令", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            if (why.isNotBlank()) Text(why, fontSize = 13.sp)
            Text("$ $cmd", fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
            when {
                result == null -> Text("等待确认 / 执行中…", fontSize = 12.sp, color = Brand)
                result.denied -> Text("✕ 未执行（${result.content}）", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                else -> {
                    Text(if (expand) "▾ 输出" else "▸ 输出（点击展开）", fontSize = 12.sp, color = Brand, modifier = Modifier.clickable { expand = !expand })
                    if (expand) Text(result.content, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                        modifier = Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState()))
                }
            }
        }
    }
}

@Composable
fun ApproveDialog(p: Pending, onDecide: (Boolean) -> Unit) {
    AlertDialog(
        onDismissRequest = {},   // 必须明确选择，点击外部不会放行
        title = { Text(if (p.dangerous) "⚠️ 高危命令，请仔细确认" else "允许执行终端命令？") },
        text = {
            Column {
                if (p.reason.isNotBlank()) Text("原因：${p.reason}")
                Spacer(Modifier.height(8.dp))
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                    Text(p.command, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                        modifier = Modifier.padding(8.dp).heightIn(max = 200.dp).verticalScroll(rememberScrollState()))
                }
                Spacer(Modifier.height(8.dp))
                Text("将以 root 身份执行，仅本次有效。", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                if (p.dangerous) Text("该命令可能造成数据丢失或系统无法启动。", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(onClick = { onDecide(true) },
                colors = if (p.dangerous) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.buttonColors()
            ) { Text(if (p.dangerous) "仍然执行" else "允许执行") }
        },
        dismissButton = { TextButton(onClick = { onDecide(false) }) { Text("拒绝") } },
    )
}

@Composable
fun SettingsDialog(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings.collectAsState().value
    val root by vm.rootState.collectAsState()
    var key by remember { mutableStateOf(s.apiKey) }
    var base by remember { mutableStateOf(s.baseUrl) }
    var sys by remember { mutableStateOf(s.system) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("设置") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions.Default)
                OutlinedTextField(base, { base = it }, label = { Text("Base URL") }, singleLine = true)
                OutlinedTextField(sys, { sys = it }, label = { Text("系统提示词") }, maxLines = 6)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Root：" + when (root) { true -> "已授予"; false -> "未授予"; null -> "未检测" }, Modifier.weight(1f))
                    OutlinedButton(onClick = { vm.checkRoot() }) { Text("检测 / 授予") }
                }
                Text("即使已授予 root，每条命令仍需你逐条确认。", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            }
        },
        confirmButton = { Button(onClick = { vm.saveSettings(Settings(key.trim(), base.trim(), sys)); onClose() }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onClose) { Text("取消") } },
    )
}
