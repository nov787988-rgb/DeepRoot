package com.deeproot.app

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val api = DeepSeekApi()

    val chats = MutableStateFlow(store.loadChats())
    val currentId = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)
    val pending = MutableStateFlow<Pending?>(null)
    val settings = MutableStateFlow(store.loadSettings())
    val deepThink = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val rootState = MutableStateFlow<Boolean?>(null)

    private var job: Job? = null
    private var decision: CompletableDeferred<Boolean>? = null

    fun newChat() { if (!busy.value) currentId.value = null }
    fun select(id: String) { if (!busy.value) currentId.value = id }
    fun delete(id: String) {
        if (busy.value) return
        chats.update { l -> l.filter { it.id != id } }
        if (currentId.value == id) currentId.value = null
        store.saveChats(chats.value)
    }

    fun saveSettings(s: Settings) { settings.value = s; store.saveSettings(s) }

    /** 点击后会弹出 su 授权（Magisk / KernelSU / APatch） */
    fun checkRoot() {
        viewModelScope.launch { rootState.value = runCatching { RootShell.isRoot() }.getOrDefault(false) }
    }

    /** 用户对某条命令的决定：true=允许执行一次，false=拒绝 */
    fun approve(ok: Boolean) { decision?.complete(ok) }

    fun stop() { job?.cancel() }

    fun send(text: String) {
        if (busy.value || text.isBlank()) return
        if (settings.value.apiKey.isBlank()) { error.value = "请先在设置中填写 API Key"; return }
        var id = currentId.value
        if (id == null || chats.value.none { it.id == id }) {
            id = UUID.randomUUID().toString()
            chats.update { listOf(Chat(id, text.take(20), emptyList(), System.currentTimeMillis())) + it }
            currentId.value = id
        }
        mutate(id) { it.copy(msgs = it.msgs + Msg("user", text), updated = System.currentTimeMillis()) }
        run(id)
    }

    /** 重新生成：丢弃最后一条用户消息之后的内容并重发 */
    fun regenerate() {
        val id = currentId.value ?: return
        if (busy.value) return
        mutate(id) { c ->
            val i = c.msgs.indexOfLast { it.role == "user" }
            if (i < 0) c else c.copy(msgs = c.msgs.take(i + 1))
        }
        run(id)
    }

    private fun run(cid: String) {
        busy.value = true
        job = viewModelScope.launch {
            try {
                agentLoop(cid)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error.value = e.message ?: e.toString()
            } finally {
                busy.value = false
                pending.value = null
                cleanup(cid)
                store.saveChats(chats.value)
            }
        }
    }

    private suspend fun agentLoop(cid: String) {
        repeat(8) {
            val s = settings.value
            val history = buildMessages(cid, s)
            mutate(cid) { it.copy(msgs = it.msgs + Msg("assistant")) }
            val c = StringBuilder(); val r = StringBuilder(); var last = 0L
            fun push() {
                val n = SystemClock.uptimeMillis()
                if (n - last < 60) return
                last = n
                val cs = c.toString(); val rs = r.toString()
                mutate(cid) { ch -> ch.copy(msgs = ch.msgs.dropLast(1) + ch.msgs.last().copy(content = cs, reasoning = rs)) }
            }
            val model = if (deepThink.value) "deepseek-reasoner" else "deepseek-chat"
            val res = api.stream(s.baseUrl, s.apiKey, model, history, TOOLS,
                { r.append(it); push() }, { c.append(it); push() })
            mutate(cid) { ch ->
                ch.copy(msgs = ch.msgs.dropLast(1) +
                    ch.msgs.last().copy(content = res.content, reasoning = res.reasoning, toolCalls = res.toolCalls))
            }
            if (res.toolCalls.isEmpty()) return

            for (tc in res.toolCalls) {
                val args = runCatching { JSONObject(tc.args) }.getOrDefault(JSONObject())
                val cmd = args.optString("command")
                val why = args.optString("reason")
                var denied = false
                val out = if (tc.name != "run_shell" || cmd.isBlank()) {
                    "错误：未知工具或缺少 command 参数"
                } else {
                    // 关键：root 命令必须经用户逐条批准
                    val d = CompletableDeferred<Boolean>()
                    decision = d
                    pending.value = Pending(tc.id, cmd, why, isDangerous(cmd))
                    val ok = d.await()
                    pending.value = null
                    if (ok) RootShell.exec(cmd) else { denied = true; "用户拒绝执行该命令" }
                }
                mutate(cid) { it.copy(msgs = it.msgs + Msg("tool", out, toolCallId = tc.id, denied = denied)) }
            }
        }
    }

    private fun buildMessages(cid: String, s: Settings): JSONArray {
        val msgs = chats.value.first { it.id == cid }.msgs
        val lastUser = msgs.indexOfLast { it.role == "user" }
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", s.system))
        msgs.forEachIndexed { i, m ->
            val o = JSONObject().put("role", m.role)
            when (m.role) {
                "assistant" -> {
                    o.put("content", m.content)
                    if (m.toolCalls.isNotEmpty()) {
                        o.put("tool_calls", JSONArray().also { a ->
                            m.toolCalls.forEach {
                                a.put(JSONObject().put("id", it.id).put("type", "function")
                                    .put("function", JSONObject().put("name", it.name).put("arguments", it.args)))
                            }
                        })
                        // 思考模式下，同一轮的工具调用需要回传 reasoning_content
                        if (i > lastUser && m.reasoning.isNotEmpty()) o.put("reasoning_content", m.reasoning)
                    }
                }
                "tool" -> o.put("tool_call_id", m.toolCallId).put("content", m.content)
                else -> o.put("content", m.content)
            }
            arr.put(o)
        }
        return arr
    }

    /** 被中断时补齐未应答的 tool_call，并清掉空的占位消息，避免下次请求 400 */
    private fun cleanup(cid: String) {
        mutate(cid) { ch ->
            var l = ch.msgs
            val last = l.lastOrNull()
            if (last != null && last.role == "assistant" && last.content.isEmpty() && last.reasoning.isEmpty() && last.toolCalls.isEmpty())
                l = l.dropLast(1)
            val ai = l.indexOfLast { it.role == "assistant" && it.toolCalls.isNotEmpty() }
            if (ai >= 0) {
                val answered = l.drop(ai + 1).filter { it.role == "tool" }.mapNotNull { it.toolCallId }.toSet()
                val missing = l[ai].toolCalls.filter { it.id !in answered }
                l = l + missing.map { Msg("tool", "已取消", toolCallId = it.id, denied = true) }
            }
            ch.copy(msgs = l)
        }
    }

    private fun mutate(id: String, f: (Chat) -> Chat) {
        chats.update { l -> l.map { if (it.id == id) f(it) else it } }
    }
}
