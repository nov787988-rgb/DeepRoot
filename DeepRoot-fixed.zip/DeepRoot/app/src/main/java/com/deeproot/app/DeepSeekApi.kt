package com.deeproot.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class DeepSeekApi {
    private val client = OkHttpClient.Builder().readTimeout(180, TimeUnit.SECONDS).build()

    data class Result(val content: String, val reasoning: String, val toolCalls: List<ToolCall>)
    private class Acc(var id: String = "", var name: String = "", val args: StringBuilder = StringBuilder())

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k)

    /** OpenAI 兼容的流式 /chat/completions；回调逐段返回思考与正文 */
    suspend fun stream(
        base: String, key: String, model: String, messages: JSONArray, tools: JSONArray,
        onReasoning: (String) -> Unit, onContent: (String) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val body = JSONObject().put("model", model).put("messages", messages).put("tools", tools).put("stream", true)
            .toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(base.trimEnd('/') + "/chat/completions")
            .header("Authorization", "Bearer $key").post(body).build()
        val call = client.newCall(req)
        val handle = coroutineContext[Job]!!.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}：${resp.body?.string()?.take(300)}")
                val src = resp.body!!.source()
                val c = StringBuilder(); val r = StringBuilder()
                val acc = sortedMapOf<Int, Acc>()
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.removePrefix("data:").trim()
                    if (d == "[DONE]") break
                    if (d.isEmpty()) continue
                    val delta = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: continue
                    delta.str("reasoning_content").takeIf { it.isNotEmpty() }?.let { r.append(it); onReasoning(it) }
                    delta.str("content").takeIf { it.isNotEmpty() }?.let { c.append(it); onContent(it) }
                    delta.optJSONArray("tool_calls")?.let { arr ->
                        for (i in 0 until arr.length()) {
                            val t = arr.getJSONObject(i)
                            val a = acc.getOrPut(t.optInt("index", i)) { Acc() }
                            t.str("id").takeIf { it.isNotEmpty() }?.let { a.id = it }
                            t.optJSONObject("function")?.let { f ->
                                f.str("name").takeIf { it.isNotEmpty() }?.let { a.name = it }
                                a.args.append(f.str("arguments"))
                            }
                        }
                    }
                }
                Result(c.toString(), r.toString(), acc.values.map { ToolCall(it.id, it.name, it.args.toString()) })
            }
        } finally {
            handle.dispose()
        }
    }
}
