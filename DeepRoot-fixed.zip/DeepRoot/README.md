# DeepRoot

DeepSeek 风格的 Android 对话 App：直接调用 DeepSeek API（OpenAI 兼容），
模型可通过 `run_shell` 工具请求执行终端命令；获得 root 后，**每条命令都会弹窗询问，用户同意才执行**。

## 功能
- 流式对话 / Markdown 渲染 / 深度思考开关（deepseek-reasoner，思考过程可折叠）
- 多会话历史（本地 JSON）、新对话、删除、复制、重新生成、停止生成
- Function Calling：run_shell → 确认弹窗 → libsu(su) 执行 → 输出回传模型继续分析
- 高危命令（rm -rf /、dd of=/dev、mkfs、setprop、reboot 等）红色警示
- API Key 用 EncryptedSharedPreferences 加密存储

## 构建
Android Studio (Koala+) 打开本目录 → Sync → Run。minSdk 26 / JDK 17。
首次运行：设置里填 API Key → 点「检测/授予」，在 KernelSU/Magisk 里允许 su。

## 安全设计
- 命令执行唯一入口是 ChatViewModel.agentLoop 中的 `d.await()`，没有"始终允许"
- 弹窗点击外部不会放行；停止/异常时自动补齐未应答的 tool_call
- 30 秒超时，输出截断 8000 字符
