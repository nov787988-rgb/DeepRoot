package com.deeproot.app

import android.widget.TextView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.DpOffset
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon
import kotlinx.coroutines.launch

private val WarmBackground = Color(0xFFFFFFFF)
private val WarmSurface = Color(0xFFFFFFFF)
private val WarmInk = Color(0xFF111318)
private val WarmMuted = Color(0xFF777D87)
private val Terracotta = Color(0xFF386FE8)
private val DarkBackground = Color(0xFF090A0C)
private val DarkSurface = Color(0xFF17191D)
private val DarkInk = Color(0xFFF4F5F7)
private val DarkMuted = Color(0xFFA0A5AE)
private val DarkAccent = Color(0xFF79A7FF)

private val MotionDuration = 260
private val SoftShape = RoundedCornerShape(22.dp)
private val CardShape = RoundedCornerShape(28.dp)
private val BubbleShape = RoundedCornerShape(26.dp)
private val InputShape = RoundedCornerShape(34.dp)

@Composable
fun DTUTheme(font: AppFontSpec = AppFontSpec(), content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = DarkAccent, onPrimary = Color(0xFF211713),
        background = DarkBackground, onBackground = DarkInk,
        surface = Color(0xFF111317), onSurface = DarkInk,
        surfaceVariant = Color(0xFF1F2328), onSurfaceVariant = DarkMuted,
        primaryContainer = Color(0xFF22408A), onPrimaryContainer = Color(0xFFDCE6FF),
        secondaryContainer = Color(0xFF2A3350), onSecondaryContainer = Color(0xFFDCE6FF),
        secondary = DarkAccent, outline = Color(0xFF343941),
        error = Color(0xFFE08A7A)
    ) else lightColorScheme(
        primary = Terracotta, onPrimary = Color.White,
        background = WarmBackground, onBackground = WarmInk,
        surface = WarmSurface, onSurface = WarmInk,
        surfaceVariant = Color(0xFFECEEF3), onSurfaceVariant = WarmMuted,
        primaryContainer = Color(0xFFDCE6FF), onPrimaryContainer = Color(0xFF12307A),
        secondaryContainer = Color(0xFFE2E8F8), onSecondaryContainer = Color(0xFF12307A),
        secondary = Terracotta, outline = Color(0xFFDDE0E5),
        error = Color(0xFFB85E4B)
    )
    val family = remember(font) { fontFamilyOf(font) }
    fun TextStyle.fam() = if (family != null) copy(fontFamily = family) else this
    val base = Typography()
    CompositionLocalProvider(LocalAppFont provides font) {
        MaterialTheme(colorScheme = scheme, shapes = Shapes(
            extraSmall = RoundedCornerShape(14.dp), small = RoundedCornerShape(18.dp), medium = RoundedCornerShape(22.dp),
            large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(34.dp)
        ), typography = Typography(
            displayLarge = base.displayLarge.fam(), displayMedium = base.displayMedium.fam(), displaySmall = base.displaySmall.fam(),
            headlineLarge = base.headlineLarge.fam(), headlineMedium = base.headlineMedium.fam(), headlineSmall = base.headlineSmall.fam(),
            titleMedium = base.titleMedium.fam(), titleSmall = base.titleSmall.fam(),
            bodySmall = base.bodySmall.fam(), labelMedium = base.labelMedium.fam(), labelSmall = base.labelSmall.fam(),
            bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 26.sp, color = scheme.onSurface).fam(),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 22.sp, color = scheme.onSurface).fam(),
            titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold).fam(),
            labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium).fam()
        ), content = content)
    }
}

/** 边缘高斯模糊渐变：把内容层再画一份，模糊后用渐变蒙版（边缘不透明 → 内侧透明）。API<31 退化为纯渐变。 */
@Composable
private fun EdgeBlur(layer: GraphicsLayer, height: Dp, top: Boolean, tint: Color, modifier: Modifier = Modifier) {
    if (height <= 0.dp) return
    val radius = with(LocalDensity.current) { 18.dp.toPx() }
    val mask = if (top) Brush.verticalGradient(0f to Color.Black, .45f to Color.Black.copy(alpha = .65f), 1f to Color.Transparent)
               else Brush.verticalGradient(0f to Color.Transparent, .55f to Color.Black.copy(alpha = .65f), 1f to Color.Black)
    Box(
        modifier.fillMaxWidth().height(height)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent { drawContent(); drawRect(mask, blendMode = BlendMode.DstIn) }
    ) {
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    if (android.os.Build.VERSION.SDK_INT >= 31) renderEffect = BlurEffect(radius, radius, TileMode.Clamp)
                }
                .drawBehind {
                    val dy = if (top) 0f else (layer.size.height - size.height).toFloat()
                    clipRect { translate(top = -dy) { drawLayer(layer) } }
                    drawRect(tint.copy(alpha = .30f))
                }
        )
    }
}

/**
 * 悬浮边缘阴影：只画在形状外侧（内部镂空），所以半透明背景下阴影不会透出来；
 * 用多层由宽到窄的描边叠加出向外渐隐的柔和阴影，并整体略微下移，增强悬浮感。
 */
@Composable
internal fun Modifier.edgeShadow(shape: Shape, spread: Dp = 12.dp, offsetY: Dp = 3.dp, strength: Float = 1f): Modifier {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    return this.drawBehind {
        val outline = shape.createOutline(size, layoutDirection, this)
        val path = Path().apply {
            when (outline) {
                is Outline.Rectangle -> addRect(outline.rect)
                is Outline.Rounded -> addRoundRect(outline.roundRect)
                is Outline.Generic -> addPath(outline.path)
            }
        }
        val steps = 8
        val spreadPx = spread.toPx()
        val perLayer = (if (dark) .60f else .20f) * strength / steps * 1.6f
        clipPath(path, ClipOp.Difference) {
            translate(top = offsetY.toPx()) {
                for (i in steps downTo 1) {
                    drawPath(path, Color.Black.copy(alpha = perLayer), style = Stroke(width = 2f * spreadPx * i / steps, join = StrokeJoin.Round))
                }
            }
        }
    }
}

/** 对话列表行：点击打开；长按弹出圆润菜单（重命名 / 置顶 / 多选 / 删除）；多选模式下显示圆形勾选 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(
    chat: Chat, current: Boolean, selectMode: Boolean, checked: Boolean,
    onClick: () -> Unit, onRename: () -> Unit, onPin: () -> Unit, onMultiSelect: () -> Unit, onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val cs = MaterialTheme.colorScheme
    Box {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(if (menu || current || checked) cs.surfaceVariant else Color.Transparent)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = { if (!selectMode) { haptic.performHapticFeedback(HapticFeedbackType.LongPress); menu = true } }
                )
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectMode) {
                Box(
                    Modifier.size(22.dp).clip(CircleShape)
                        .background(if (checked) cs.primary else Color.Transparent)
                        .then(if (checked) Modifier else Modifier.border(2.dp, cs.outline, CircleShape)),
                    contentAlignment = Alignment.Center
                ) { if (checked) Icon24(Ic.Check, cs.onPrimary, 14.dp, weight = 3f) }
                Spacer(Modifier.width(12.dp))
            }
            Text(chat.title.ifBlank { "新对话" }, Modifier.weight(1f), maxLines = 1, fontSize = 14.sp)
            if (chat.pinned) { Spacer(Modifier.width(8.dp)); Icon24(Ic.Pin, cs.primary, 15.dp) }
        }
        DropdownMenu(
            expanded = menu, onDismissRequest = { menu = false },
            offset = DpOffset(86.dp, (-2).dp),
            shape = RoundedCornerShape(28.dp), containerColor = cs.surface,
            tonalElevation = 0.dp, shadowElevation = 14.dp,
            modifier = Modifier.width(200.dp)
        ) {
            @Composable
            fun item(icon: Ic, label: String, color: Color, divider: Boolean = true, action: () -> Unit) {
                DropdownMenuItem(
                    text = { Text(label, fontSize = 16.sp, color = color) },
                    leadingIcon = { Icon24(icon, color, 22.dp) },
                    onClick = { menu = false; action() },
                    contentPadding = PaddingValues(horizontal = 22.dp),
                    modifier = Modifier.height(54.dp)
                )
                if (divider) HorizontalDivider(color = cs.outline.copy(alpha = .35f), thickness = .6.dp)
            }
            item(Ic.Edit, "重命名", cs.onSurface, action = onRename)
            item(Ic.Pin, if (chat.pinned) "取消置顶" else "置顶", cs.onSurface, action = onPin)
            item(Ic.Checklist, "多选", cs.onSurface, action = onMultiSelect)
            item(Ic.Trash, "删除", cs.error, divider = false, action = onDelete)
        }
    }
}

/** 顶栏圆形悬浮按钮：半透明饱满圆底，active 时用主色容器高亮 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoundBarButton(onClick: () -> Unit, active: Boolean = false, content: @Composable () -> Unit) {
    val bg = if (active) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .94f) else MaterialTheme.colorScheme.surface.copy(alpha = .88f)
    Surface(
        onClick = onClick, shape = CircleShape, color = bg,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (active) 0f else .22f)),
        modifier = Modifier.padding(horizontal = 4.dp).size(44.dp).edgeShadow(CircleShape, 10.dp, 3.dp)
    ) { Box(contentAlignment = Alignment.Center) { content() } }
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun App(vm: ChatViewModel, titleAlpha: Float = 1f, onTitleBounds: (Rect) -> Unit = {}) {
    val chats by vm.chats.collectAsState()
    val cur by vm.currentId.collectAsState()
    val busy by vm.busy.collectAsState()
    val pending by vm.pending.collectAsState()
    val deep by vm.deepThink.collectAsState()
    val web by vm.webSearch.collectAsState()
    val strict by vm.strictMode.collectAsState()
    val err by vm.error.collectAsState()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var showSettings by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var showStrictConfirm by remember { mutableStateOf(false) }
    var strictSeen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var selectMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var renameTarget by remember { mutableStateOf<Chat?>(null) }
    var confirmBatchDelete by remember { mutableStateOf(false) }
    // 抽屉收起时退出多选
    LaunchedEffect(drawer.currentValue) { if (drawer.currentValue == DrawerValue.Closed) { selectMode = false; selected = emptySet() } }
    val chat = chats.find { it.id == cur }
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) vm.addAttachments(uris) }

    LaunchedEffect(strict) {
        // 切换后给出状态提示（首次进入时不提示）
        if (strictSeen) { snack.currentSnackbarData?.dismiss(); snack.showSnackbar(if (strict) "严格模式已开启：所有终端操作都会先询问确认" else "严格模式已关闭：只读命令直接执行") }
        strictSeen = true
    }
    LaunchedEffect(err) { err?.let { snack.showSnackbar(it); vm.error.value = null } }

    if (showStrictConfirm) {
        AlertDialog(
            onDismissRequest = { showStrictConfirm = false },
            title = { Text("严格模式") },
            text = { Text("开启严格模式后，所有操作将都会询问确认再执行") },
            confirmButton = { Button(onClick = { vm.strictMode.value = true; showStrictConfirm = false }, shape = CircleShape, modifier = Modifier.height(46.dp)) { Text("确认") } },
            dismissButton = { FilledTonalButton(onClick = { showStrictConfirm = false }, shape = CircleShape, modifier = Modifier.height(46.dp)) { Text("取消") } }
        )
    }

    renameTarget?.let { target ->
        var text by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("重命名") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true, shape = SoftShape, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(enabled = text.isNotBlank(), onClick = { vm.rename(target.id, text); renameTarget = null }, shape = CircleShape, modifier = Modifier.height(46.dp)) { Text("保存") } },
            dismissButton = { FilledTonalButton(onClick = { renameTarget = null }, shape = CircleShape, modifier = Modifier.height(46.dp)) { Text("取消") } }
        )
    }
    if (confirmBatchDelete) {
        AlertDialog(
            onDismissRequest = { confirmBatchDelete = false },
            title = { Text("删除对话") },
            text = { Text("确定删除所选的 ${selected.size} 个对话吗？删除后无法恢复。") },
            confirmButton = {
                Button(onClick = { vm.deleteMany(selected); selected = emptySet(); selectMode = false; confirmBatchDelete = false },
                    shape = CircleShape, modifier = Modifier.height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White)) { Text("删除") }
            },
            dismissButton = { FilledTonalButton(onClick = { confirmBatchDelete = false }, shape = CircleShape, modifier = Modifier.height(46.dp)) { Text("取消") } }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        scrimColor = MaterialTheme.colorScheme.scrim.copy(alpha = .28f),
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                drawerShape = RoundedCornerShape(topEnd = 32.dp, bottomEnd = 32.dp),
                modifier = Modifier.widthIn(max = 340.dp).fillMaxHeight()
            ) {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Text("DeepTerminal Ultra", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("搜索对话") }, shape = CircleShape,
                        leadingIcon = { Icon24(Ic.Search, MaterialTheme.colorScheme.onSurfaceVariant, 20.dp) }
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(if (selectMode) "已选择 ${selected.size} 项" else "最近", color = MaterialTheme.colorScheme.outline, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp))
                    Spacer(Modifier.height(4.dp))
                    // 置顶的对话排在前面，其余保持原有顺序
                    val filtered = chats.filter { it.title.contains(search, true) }.sortedByDescending { it.pinned }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        itemsIndexed(filtered, key = { _, c -> c.id }) { _, c ->
                            ChatRow(
                                chat = c, current = c.id == cur, selectMode = selectMode, checked = c.id in selected,
                                onClick = {
                                    if (selectMode) selected = if (c.id in selected) selected - c.id else selected + c.id
                                    else { vm.select(c.id); scope.launch { drawer.close() } }
                                },
                                onRename = { renameTarget = c },
                                onPin = { vm.togglePin(c.id) },
                                onMultiSelect = { selectMode = true; selected = setOf(c.id) },
                                onDelete = { vm.delete(c.id) }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        if (selectMode) {
                            // 多选模式：左下角取消，右下角删除所选
                            Surface(onClick = { selectMode = false; selected = emptySet() }, shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(52.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon24(Ic.Close, MaterialTheme.colorScheme.onSurface, 22.dp) }
                            }
                            Spacer(Modifier.weight(1f))
                            Button(
                                onClick = { confirmBatchDelete = true }, enabled = selected.isNotEmpty(), shape = CircleShape,
                                modifier = Modifier.height(52.dp).edgeShadow(CircleShape, 8.dp, 2.dp, .7f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White)
                            ) { Icon24(Ic.Trash, Color.White, 20.dp); Spacer(Modifier.width(8.dp)); Text("删除" + if (selected.isNotEmpty()) "（${selected.size}）" else "", fontWeight = FontWeight.SemiBold) }
                        } else {
                            // 左下角：圆形设置按钮；右下角：新建对话
                            Surface(onClick = { showSettings = true; scope.launch { drawer.close() } }, shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(52.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon24(Ic.Sliders, MaterialTheme.colorScheme.onSurface, 22.dp) }
                            }
                            Spacer(Modifier.weight(1f))
                            Button(
                                onClick = { vm.newChat(); scope.launch { drawer.close() } }, shape = CircleShape,
                                modifier = Modifier.height(52.dp).edgeShadow(CircleShape, 8.dp, 2.dp, .7f),
                                contentPadding = PaddingValues(horizontal = 22.dp)
                            ) { Icon24(Ic.Plus, MaterialTheme.colorScheme.onPrimary, 20.dp); Spacer(Modifier.width(8.dp)); Text("新建对话", fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }
            }
        }
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) {
            val density = LocalDensity.current
            var topPx by remember { mutableIntStateOf(0) }
            var bottomPx by remember { mutableIntStateOf(0) }
            val topH = with(density) { topPx.toDp() }
            val bottomH = with(density) { bottomPx.toDp() }
            val blurFade = 28.dp
            val blurLayer = rememberGraphicsLayer()
            val msgs = chat?.msgs.orEmpty()
            val results = remember(msgs) { msgs.filter { it.role == "tool" }.associateBy { it.toolCallId ?: "" } }
            val shown = msgs.filter { it.role != "tool" }
            val listState = rememberLazyListState()
            var followLatest by remember { mutableStateOf(true) }
            LaunchedEffect(listState) {
                snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
                    .collect { (index, _) -> followLatest = index >= (shown.size - 3).coerceAtLeast(0) }
            }
            LaunchedEffect(shown.size, shown.lastOrNull()?.content?.length, shown.lastOrNull()?.reasoning?.length) {
                if (shown.isNotEmpty() && followLatest) listState.animateScrollToItem(shown.lastIndex)
            }
            Box(Modifier.fillMaxSize()) {
                // 1) 聊天内容：同时录制到 blurLayer，供上下边缘的模糊层复用
                Box(Modifier.fillMaxSize().drawWithContent {
                    blurLayer.record { this@drawWithContent.drawContent() }
                    drawLayer(blurLayer)
                }) {

                if (shown.isEmpty()) {
                    // DTU 标题与副标题保持原位：下方用与原提示词卡片同尺寸的"隐形占位"撑住布局，
                    // 这样去掉提示词后标题位置分毫不变，启动动画的落点也不受影响。
                    Column(
                        Modifier.fillMaxSize().padding(start = 30.dp, end = 30.dp, top = topH, bottom = bottomH),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("DTU", fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.onGloballyPositioned { onTitleBounds(it.boundsInRoot()) }.graphicsLayer { alpha = titleAlpha })
                        Spacer(Modifier.height(9.dp))
                        Text("AI 智能助手 · Root 终端", color = MaterialTheme.colorScheme.outline, fontSize = 14.sp, letterSpacing = .4.sp)
                        Spacer(Modifier.height(30.dp))
                        listOf("搜索今天的 AI 行业动态", "帮我检查一段代码", "如何安全地管理 Root 权限？", "解释一个复杂概念").forEach { placeholder ->
                            Text(placeholder, Modifier.fillMaxWidth().padding(vertical = 5.dp).padding(horizontal = 20.dp, vertical = 16.dp),
                                fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.Transparent)
                        }
                    }
                    // 图标位于屏幕正中，下方是无框问候语（随时间段变化）
                    val greeting = remember { greetingNow() }
                    Box(Modifier.fillMaxSize()) {
                        Box(Modifier.align(Alignment.Center).size(132.dp)) {
                            Image(painterResource(R.drawable.logo_ink), null, Modifier.fillMaxSize(),
                                colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground))
                            Image(painterResource(R.drawable.logo_whale), null, Modifier.fillMaxSize())
                        }
                        Text(greeting, Modifier.align(Alignment.Center).offset(y = 66.dp + 30.dp).padding(horizontal = 30.dp),
                            fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = topH + 12.dp, bottom = bottomH + 18.dp),
                        verticalArrangement = Arrangement.spacedBy(22.dp)
                    ) {
                        itemsIndexed(shown, key = { index, _ -> "${chat?.id}:$index" }) { index, message ->
                            AnimatedVisibility(visible = true, enter = fadeIn(tween(220, easing = FastOutSlowInEasing)) + slideInVertically(tween(220, easing = FastOutSlowInEasing)) { it / 8 }) {
                                MsgItem(message, results, index == shown.lastIndex, busy, pending, { vm.approve(true) }, { vm.approve(false) }) { vm.regenerate() }
                            }
                        }
                    }
                }
                }
                // 2) 顶部/底部高斯模糊渐变层（边缘最模糊，向内渐变为透明）
                EdgeBlur(blurLayer, topH + blurFade, top = true, tint = MaterialTheme.colorScheme.background, modifier = Modifier.align(Alignment.TopCenter))
                EdgeBlur(blurLayer, bottomH + blurFade, top = false, tint = MaterialTheme.colorScheme.background, modifier = Modifier.align(Alignment.BottomCenter))
                    AnimatedVisibility(
                        visible = !followLatest && shown.isNotEmpty(),
                        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = bottomH + 12.dp),
                        enter = fadeIn() + scaleIn(), exit = fadeOut()
                    ) {
                        FilledTonalButton(onClick = { scope.launch { listState.animateScrollToItem((shown.size - 1).coerceAtLeast(0)); followLatest = true } }, shape = CircleShape, modifier = Modifier.edgeShadow(CircleShape, 10.dp, 3.dp)) {
                            Text("↓ 回到底部")
                        }
                    }
                SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = bottomH))
                // 3) 顶栏（透明）
                Box(Modifier.align(Alignment.TopCenter).onSizeChanged { topPx = it.height }) {
                TopAppBar(
                    title = {
                        AnimatedVisibility(visible = true, enter = fadeIn(tween(MotionDuration)), exit = fadeOut(tween(160))) {
                            Text(chat?.title.orEmpty().ifBlank { "DTU" }, modifier = Modifier
                                .edgeShadow(CircleShape, 10.dp, 3.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = .88f))
                                .padding(horizontal = 20.dp, vertical = 11.dp),
                                maxLines = 1, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    },
                    navigationIcon = {
                        RoundBarButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon24(Ic.Menu, MaterialTheme.colorScheme.onSurface, 22.dp)
                        }
                    },
                    actions = {
                        // 严格模式：关闭时点击弹窗确认后开启；开启时再次点击直接关闭，无弹窗
                        RoundBarButton(
                            onClick = { if (strict) vm.strictMode.value = false else showStrictConfirm = true },
                            active = strict
                        ) { Icon24(if (strict) Ic.LockClosed else Ic.LockOpen, if (strict) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface, 22.dp) }
                        RoundBarButton(onClick = { if (!busy) vm.newChat() }) {
                            Icon24(Ic.Plus, MaterialTheme.colorScheme.onSurface, 22.dp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
                )
                }
                // 4) 底部聊天框（透明）
                Box(Modifier.align(Alignment.BottomCenter).onSizeChanged { bottomPx = it.height }) {
                    var draft by remember { mutableStateOf("") }
                Column(
                    Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val chipColors = FilterChipDefaults.filterChipColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .86f),
                            labelColor = MaterialTheme.colorScheme.onSurface,
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                        FilterChip(selected = deep, onClick = { vm.deepThink.value = !deep },
                            leadingIcon = { Icon24(Ic.Bulb, if (deep) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, 18.dp) },
                            label = { Text("深度思考", fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 4.dp)) },
                            shape = CircleShape, border = null, colors = chipColors, modifier = Modifier.edgeShadow(CircleShape, 8.dp, 2.dp))
                        FilterChip(selected = web, onClick = { vm.webSearch.value = !web },
                            leadingIcon = { Icon24(Ic.Globe, if (web) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, 18.dp) },
                            label = { Text("联网搜索", fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 4.dp)) },
                            shape = CircleShape, border = null, colors = chipColors, modifier = Modifier.edgeShadow(CircleShape, 8.dp, 2.dp))
                    }
                    // 输入内容时聊天框变为不透明；未输入时保持半透明
                    val boxAlpha by animateFloatAsState(if (draft.isNotEmpty()) 1f else .86f, tween(180), label = "input-alpha")
                    Surface(
                        modifier = Modifier.edgeShadow(InputShape, 14.dp, 4.dp), // 自绘外侧阴影：只在形状外，不会透进半透明背景
                        color = MaterialTheme.colorScheme.surface.copy(alpha = boxAlpha),
                        shape = InputShape,
                        shadowElevation = 0.dp, // 不用系统阴影：半透明背景 + 系统阴影会透出"白条"
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .24f))
                    ) {
                        Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                            BasicTextField(
                                value = draft, onValueChange = { draft = it },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 34.dp, max = 132.dp),
                                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, lineHeight = 23.sp, fontFamily = MaterialTheme.typography.bodyLarge.fontFamily),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                                decorationBox = { inner ->
                                    Box {
                                        if (draft.isEmpty()) Text("和 DTU 聊聊…", color = MaterialTheme.colorScheme.outline, fontSize = 16.sp)
                                        inner()
                                    }
                                }
                            )
                            val pendingAttachments = chat?.msgs?.lastOrNull()?.takeIf { it.role == "user" }?.attachments.orEmpty()
                            if (pendingAttachments.isNotEmpty()) {
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    pendingAttachments.forEach { a ->
                                        AssistChip(onClick = { }, shape = CircleShape, label = { Text(a.name, maxLines = 1) }, leadingIcon = { Icon24(Ic.File, MaterialTheme.colorScheme.onSurfaceVariant, 16.dp) }, trailingIcon = { Icon24(Ic.Close, MaterialTheme.colorScheme.onSurfaceVariant, 16.dp, Modifier.clickable { vm.removeAttachment(a.uri) }) })
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                var addMenu by remember { mutableStateOf(false) }
                                Box {
                                    Surface(onClick = { addMenu = true }, shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(40.dp)) {
                                        Box(contentAlignment = Alignment.Center) { Icon24(Ic.Plus, MaterialTheme.colorScheme.onSurface, 20.dp) }
                                    }
                                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                                        DropdownMenuItem(text = { Text("上传文件") }, onClick = {
                                            addMenu = false
                                            attachmentPicker.launch(arrayOf("image/*", "application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/*", "application/json", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/epub+zip", "application/x-mobipocket-ebook", "application/*"))
                                        })
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                Spacer(Modifier.weight(1f))
                                val canSend = draft.isNotBlank() || pendingAttachments.isNotEmpty()
                                AnimatedContent(targetState = busy || canSend, label = "send-toggle") { sending ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = CircleShape,
                                        modifier = Modifier.size(42.dp).clickable {
                                            if (busy) vm.stop() else if (canSend) {
                                                vm.send(draft.trim()); draft = ""; focusManager.clearFocus(force = true)
                                            }
                                        }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon24(if (sending && busy) Ic.Stop else Ic.Send, MaterialTheme.colorScheme.onPrimary, 22.dp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text("DTU 可能会出错，请核实重要信息。", modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 7.dp),
                        color = MaterialTheme.colorScheme.outline, fontSize = 10.sp)
                }
                }
            }
        }
    }

    AnimatedVisibility(
        visible = showSettings,
        enter = slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(200)),
        exit = slideOutHorizontally(tween(240, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(200))
    ) { SettingsScreen(vm) { showSettings = false } }
}

/** 按当前时间段给出问候语 */
private fun greetingNow(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (h) {
        in 5..8 -> "早上好，聊些什么？"
        in 9..11 -> "上午好，想从哪里开始？"
        in 12..13 -> "中午好，有什么想法？"
        in 14..17 -> "下午好，聊聊？"
        else -> "晚间随想"
    }
}

@Composable
fun MsgItem(m: Msg, results: Map<String, Msg>, isLast: Boolean, busy: Boolean, pending: Pending?, onApprove: () -> Unit, onReject: () -> Unit, onRegen: () -> Unit) {
    if (m.role == "user") {
        if (m.attachments.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                m.attachments.forEach { a ->
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon24(Ic.File, MaterialTheme.colorScheme.onSurfaceVariant, 15.dp); Spacer(Modifier.width(6.dp)); Text(a.name, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
        if (m.content.isNotBlank()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.primary.copy(alpha = if (androidx.compose.foundation.isSystemInDarkTheme()) .28f else .16f), shape = BubbleShape,
                modifier = Modifier.widthIn(max = 320.dp)) {
                Text(m.content, Modifier.padding(horizontal = 18.dp, vertical = 13.dp), fontSize = 15.sp, lineHeight = 23.sp)
            }
        }
        return
    }
    Column(Modifier.fillMaxWidth()) {
        if (m.progress.isNotBlank()) {
            var open by remember(m.progress) { mutableStateOf(busy && isLast) }
            LaunchedEffect(busy, isLast, m.progress) { if (!busy) open = false }
            Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f),
                shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().clickable { open = !open }) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon24(Ic.Bulb, MaterialTheme.colorScheme.primary, 16.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(if (busy && isLast) "工作提要 · 正在处理" else "工作提要 · 已完成",
                            color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.weight(1f))
                        Icon24(if (open) Ic.ChevronDown else Ic.ChevronRight, MaterialTheme.colorScheme.outline, 16.dp)
                    }
                    AnimatedVisibility(open, enter = fadeIn(tween(180)), exit = fadeOut(tween(120))) {
                        Text(m.progress, modifier = Modifier.padding(top = 7.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
            Spacer(Modifier.height(9.dp))
        }
        if (m.content.isNotEmpty()) Markdown(m.content)
        m.toolCalls.forEach { tc -> ToolCard(tc, results[tc.id], pending, onApprove, onReject) }
        if (m.content.isEmpty() && m.reasoning.isEmpty() && m.progress.isEmpty() && m.toolCalls.isEmpty() && busy && isLast) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("正在整理思路…", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp)
            }
        }
        if (isLast && !busy && m.content.isNotEmpty()) {
            val clip = LocalClipboardManager.current
            var copied by remember(m.content) { mutableStateOf(false) }
            LaunchedEffect(copied) { if (copied) { kotlinx.coroutines.delay(1500); copied = false } }
            val pill = RoundedCornerShape(22.dp)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f), shape = pill,
                    modifier = Modifier.clip(pill).clickable { clip.setText(AnnotatedString(m.content)); copied = true }) {
                    val c1 = if (copied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon24(if (copied) Ic.Check else Ic.Copy, c1, 16.dp); Spacer(Modifier.width(6.dp))
                        Text(if (copied) "已复制" else "复制", fontSize = 13.sp, color = c1)
                    }
                }
                Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f), shape = pill,
                    modifier = Modifier.clip(pill).clickable(onClick = onRegen)) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon24(Ic.Refresh, MaterialTheme.colorScheme.onSurfaceVariant, 16.dp); Spacer(Modifier.width(6.dp))
                        Text("重新生成", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun Markdown(text: String) {
    val ctx = LocalContext.current
    val markwon = remember { Markwon.create(ctx) }
    val color = MaterialTheme.colorScheme.onSurface.toArgb()
    val linkColor = MaterialTheme.colorScheme.primary.toArgb()
    val fontSpec = LocalAppFont.current
    val tf = remember(fontSpec) { typefaceOf(fontSpec) }
    AndroidView(
        factory = { TextView(it).apply {
            textSize = 16f
            setTextIsSelectable(true)
            setLineSpacing(7f, 1.08f)
            setPadding(0, 0, 0, 0)
        } },
        update = {
            it.typeface = tf
            it.setTextColor(color)
            it.setLinkTextColor(linkColor)
            markwon.setMarkdown(it, text)
        },
    )
}

@Composable
fun ToolCard(tc: ToolCall, result: Msg?, pending: Pending?, onApprove: () -> Unit, onReject: () -> Unit) {
    val args = runCatching { org.json.JSONObject(tc.args) }.getOrNull()
    // 联网工具完全在后台运行，不在聊天界面展示搜索卡片或网页内容。
    if (tc.name == "web_search" || tc.name == "read_url") return
    val cmd = args?.optString("command").orEmpty()
    val why = args?.optString("reason").orEmpty()
    // 请求确认后：代码与输出默认折叠；只有先展开代码，才能展开终端输出。
    var codeOpen by remember(tc.id) { mutableStateOf(false) }
    var outOpen by remember(tc.id) { mutableStateOf(false) }
    val awaiting = result == null && pending?.callId == tc.id
    val primary = MaterialTheme.colorScheme.primary
    @Composable
    fun CodeBlock() {
        Surface(color = MaterialTheme.colorScheme.background, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
            Text("$ $cmd", fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 19.sp,
                modifier = Modifier.padding(12.dp))
        }
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = CardShape,
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .3f))
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon24(Ic.Terminal, primary, 24.dp)
                Spacer(Modifier.weight(1f))
                Text(if (isDangerous(cmd)) "高风险" else if (awaiting || result == null) "待确认" else if (result.denied) "已拒绝" else "已执行", fontSize = 11.sp, color = if (isDangerous(cmd)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline)
            }
            if (why.isNotBlank()) Text(why, modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
            if (awaiting) {
                // 等待确认时必须看得到命令，确认前不折叠
                CodeBlock()
                Text("待确认 · 仅在你点击确认后调用 su 执行一次", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = primary)
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onReject, shape = CircleShape, modifier = Modifier.weight(1f).height(48.dp)) { Text("拒绝") }
                    Button(onClick = onApprove, shape = CircleShape, modifier = Modifier.weight(1f).height(48.dp)) { Text("确认执行", fontWeight = FontWeight.SemiBold) }
                }
                if (pending?.dangerous == true) Text("高风险操作：请确认命令内容和影响。", modifier = Modifier.padding(top = 7.dp), color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            } else {
                when {
                    result == null -> Text("等待执行队列…", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                    result.denied -> Text("未执行 · 你已拒绝此命令", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    else -> {
                        val failed = Regex("exit=([1-9][0-9]*)").containsMatchIn(result.content)
                        Text(if (failed) "执行失败 · 请检查退出码和 stderr" else "Root 命令执行完成", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = if (failed) MaterialTheme.colorScheme.error else primary)
                    }
                }
                Row(Modifier.padding(top = 7.dp).clip(CircleShape).clickable { codeOpen = !codeOpen; if (!codeOpen) outOpen = false }.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon24(if (codeOpen) Ic.ChevronDown else Ic.ChevronRight, primary, 16.dp); Spacer(Modifier.width(4.dp))
                    Text(if (codeOpen) "收起代码" else "展开代码", fontSize = 12.sp, color = primary)
                }
                AnimatedVisibility(codeOpen, enter = fadeIn(tween(180)), exit = fadeOut(tween(130))) {
                    Column {
                        CodeBlock()
                        // 终端输出只有在代码展开后才出现，且默认折叠
                        if (result != null && !result.denied) {
                            Row(Modifier.padding(top = 9.dp).clip(CircleShape).clickable { outOpen = !outOpen }.padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Icon24(if (outOpen) Ic.ChevronDown else Ic.ChevronRight, primary, 16.dp); Spacer(Modifier.width(4.dp))
                                Text(if (outOpen) "收起终端输出" else "展开终端输出", fontSize = 12.sp, color = primary)
                            }
                            AnimatedVisibility(outOpen, enter = fadeIn(tween(180)), exit = fadeOut(tween(130))) {
                                Text(result.content, modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState()).padding(top = 8.dp),
                                    fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
