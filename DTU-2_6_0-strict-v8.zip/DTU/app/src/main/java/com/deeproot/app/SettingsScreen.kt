package com.deeproot.app

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CardR = RoundedCornerShape(30.dp)
private val FieldR = RoundedCornerShape(22.dp)

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = MaterialTheme.colorScheme.surface,
    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = .35f)
)

/** 设置页的分组卡片：圆形图标 + 标题 + 内容，整块饱满圆润 */
@Composable
private fun SectionCard(icon: Ic, title: String, hint: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = CardR, color = cs.surfaceVariant.copy(alpha = .6f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(cs.primaryContainer), contentAlignment = Alignment.Center) {
                    Icon24(icon, cs.onPrimaryContainer, 22.dp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    if (hint != null) Text(hint, fontSize = 12.sp, color = cs.onSurfaceVariant)
                }
            }
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FontCard(label: String, hint: String, family: FontFamily, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, shape = RoundedCornerShape(24.dp), color = cs.surface, modifier = modifier,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) cs.primary else cs.outline.copy(alpha = .3f))
    ) {
        Box {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Text("Aa 你好", fontFamily = family, fontSize = 22.sp, maxLines = 1)
                Spacer(Modifier.height(6.dp))
                Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(hint, fontSize = 11.sp, color = cs.outline, maxLines = 1)
            }
            if (selected) Box(
                Modifier.align(Alignment.TopEnd).padding(10.dp).size(22.dp).clip(CircleShape).background(cs.primary),
                contentAlignment = Alignment.Center
            ) { Icon24(Ic.Check, cs.onPrimary, 14.dp, weight = 3f) }
        }
    }
}

/** 独立的设置界面（取代原来的弹窗）。返回键或“保存”都会保存；字体选择即时生效。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val s = vm.settings.collectAsState().value
    val root by vm.rootState.collectAsState()
    val fontKey by vm.fontKey.collectAsState()
    val customName by vm.customFontName.collectAsState()
    val customPath by vm.customFontPath.collectAsState()
    val fontError by vm.fontError.collectAsState()
    val availableModels by vm.modelOptions.collectAsState()
    val fetchState by vm.modelFetchState.collectAsState()
    var key by remember { mutableStateOf(s.apiKey) }
    var base by remember { mutableStateOf(s.baseUrl) }
    var sys by remember { mutableStateOf(s.system) }
    var model by remember { mutableStateOf(s.model) }
    var modelMenu by remember { mutableStateOf(false) }

    val save = { vm.saveSettings(Settings(key.trim(), base.trim(), sys, model, vm.modelOptions.value)) }
    BackHandler { save(); onClose() }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.importFont(it) } }

    Surface(Modifier.fillMaxSize(), color = cs.background, contentColor = cs.onBackground) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                // 顶栏：圆形返回 + 标题
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        onClick = { save(); onClose() }, shape = CircleShape, color = cs.surfaceVariant,
                        modifier = Modifier.size(46.dp)
                    ) { Box(contentAlignment = Alignment.Center) { Icon24(Ic.Back, cs.onSurface, 22.dp) } }
                    Spacer(Modifier.width(14.dp))
                    Text("设置", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding()
                        .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 112.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // ===== 模型连接 =====
                    SectionCard(Ic.Chip, "模型连接", "API 地址、密钥与模型") {
                        OutlinedTextField(key, { key = it }, shape = FieldR, colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
                            label = { Text("API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                            leadingIcon = { Icon24(Ic.Key, cs.onSurfaceVariant, 20.dp) })
                        OutlinedTextField(base, { base = it }, shape = FieldR, colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
                            label = { Text("API Base URL") }, singleLine = true,
                            leadingIcon = { Icon24(Ic.Link, cs.onSurfaceVariant, 20.dp) })
                        Text("联网搜索使用 DeepSeek 官方 Search / Fetch 接口，无需第三方 Key；需使用官方 API 地址。搜索与网页抓取按成功请求计费。",
                            fontSize = 11.sp, lineHeight = 16.sp, color = cs.outline)
                        ExposedDropdownMenuBox(expanded = modelMenu, onExpandedChange = { modelMenu = !modelMenu }) {
                            OutlinedTextField(
                                value = model, onValueChange = { model = it }, shape = FieldR, colors = fieldColors(),
                                label = { Text("模型 ID（可手动输入）") }, singleLine = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelMenu) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                                availableModels.forEach { option ->
                                    DropdownMenuItem(text = { Text(option) }, onClick = { model = option; modelMenu = false })
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FilledTonalButton(onClick = { vm.fetchModels(base.trim(), key.trim()) }, shape = CircleShape, modifier = Modifier.height(46.dp)) {
                                Icon24(Ic.Refresh, androidx.compose.material3.LocalContentColor.current, 18.dp); Spacer(Modifier.width(8.dp)); Text("刷新模型列表")
                            }
                            Text("${availableModels.size} 个已缓存", fontSize = 12.sp, color = cs.outline)
                        }
                        fetchState?.let {
                            Text(it, fontSize = 12.sp, color = if (it.startsWith("获取失败") || it.startsWith("请先")) cs.error else cs.primary)
                        }
                        Text("自动请求当前服务商的 /models 接口。切换 API 地址或 Key 后请重新刷新；也可以直接手动输入模型 ID。",
                            fontSize = 11.sp, lineHeight = 16.sp, color = cs.outline)
                    }

                    // ===== 字体 =====
                    SectionCard(Ic.Font, "字体", "选择后立即生效") {
                        val items = FONT_PRESETS.map { Triple(it.key, it.label, it.hint) } +
                            Triple("custom", "自定义", customName ?: "导入 .ttf / .otf")
                        items.chunked(2).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                rowItems.forEach { (k, label, hint) ->
                                    FontCard(
                                        label = label, hint = hint,
                                        family = previewFamilyOf(AppFontSpec(k, customPath)),
                                        selected = fontKey == k, modifier = Modifier.weight(1f),
                                        onClick = { if (k == "custom" && customPath == null) fontPicker.launch(arrayOf("*/*")) else vm.setFont(k) }
                                    )
                                }
                                if (rowItems.size < 2) Spacer(Modifier.weight(1f))
                            }
                        }
                        FilledTonalButton(onClick = { fontPicker.launch(arrayOf("*/*")) }, shape = CircleShape, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Icon24(Ic.Plus, androidx.compose.material3.LocalContentColor.current, 20.dp); Spacer(Modifier.width(8.dp)); Text("导入字体文件")
                        }
                        fontError?.let { Text(it, fontSize = 12.sp, color = cs.error) }
                        Text("预设字体主要改变英文与数字，中文字形取决于系统；想改中文字体请导入 .ttf / .otf 字体文件。选“默认”时，界面用系统字体、回答保持衬线。",
                            fontSize = 11.sp, lineHeight = 16.sp, color = cs.outline)
                    }

                    // ===== 系统提示词 =====
                    SectionCard(Ic.Chat, "系统提示词", "决定 DTU 的角色与行为准则") {
                        OutlinedTextField(sys, { sys = it }, shape = FieldR, colors = fieldColors(), modifier = Modifier.fillMaxWidth(), minLines = 4, maxLines = 10)
                        TextButton(onClick = { sys = DEFAULT_SYSTEM }, shape = CircleShape) { Text("恢复默认提示词") }
                    }

                    // ===== Root 权限 =====
                    SectionCard(Ic.Terminal, "Root 权限", "终端命令执行") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val dot = when (root) { true -> Color(0xFF2E9E5B); false -> cs.error; null -> cs.outline }
                            Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
                            Spacer(Modifier.width(10.dp))
                            Text("状态：" + when (root) { true -> "已授予"; false -> "未授予"; null -> "未检测" }, Modifier.weight(1f), fontSize = 15.sp)
                            FilledTonalButton(onClick = { vm.checkRoot() }, shape = CircleShape, modifier = Modifier.height(44.dp)) { Text("检测 / 授予") }
                        }
                        Text("每条 Root 命令都会在对话内显示。严格模式关闭时，只读命令直接执行；开启时所有命令都由你逐条确认。",
                            fontSize = 12.sp, lineHeight = 18.sp, color = cs.outline)
                    }
                }
            }
            // 悬浮保存按钮
            Button(
                onClick = { save(); onClose() }, shape = CircleShape,
                modifier = Modifier.align(Alignment.BottomEnd)
                    .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
                    .padding(end = 20.dp, bottom = 18.dp).height(54.dp).edgeShadow(CircleShape, 10.dp, 3.dp, .8f),
                contentPadding = PaddingValues(horizontal = 26.dp)
            ) { Icon24(Ic.Check, cs.onPrimary, 20.dp); Spacer(Modifier.width(8.dp)); Text("保存", fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
        }
    }
}
