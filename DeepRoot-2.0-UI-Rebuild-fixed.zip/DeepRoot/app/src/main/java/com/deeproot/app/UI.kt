package com.deeproot.app

import android.widget.TextView
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon
import kotlinx.coroutines.launch

private val WarmBackground = Color(0xFFFAF9F5)
private val WarmSurface = Color(0xFFF2F0E9)
private val WarmInk = Color(0xFF1F1E1D)
private val WarmMuted = Color(0xFF817D76)
private val Terracotta = Color(0xFFD97757)
private val DarkBackground = Color(0xFF262624)
private val DarkSurface = Color(0xFF32312E)
private val DarkInk = Color(0xFFF5F4EE)
private val DarkMuted = Color(0xFFB5B0A7)
private val DarkAccent = Color(0xFFE18B6D)

private val MotionDuration = 260
private val SoftShape = RoundedCornerShape(18.dp)
private val CardShape = RoundedCornerShape(22.dp)

@Composable
fun DeepRootTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = DarkAccent, onPrimary = Color(0xFF211713),
        background = DarkBackground, onBackground = DarkInk,
        surface = DarkBackground, onSurface = DarkInk,
        surfaceVariant = DarkSurface, onSurfaceVariant = DarkMuted,
        secondary = DarkAccent, outline = Color(0xFF625E58),
        error = Color(0xFFE08A7A)
    ) else lightColorScheme(
        primary = Terracotta, onPrimary = Color.White,
        background = WarmBackground, onBackground = WarmInk,
        surface = WarmBackground, onSurface = WarmInk,
        surfaceVariant = WarmSurface, onSurfaceVariant = WarmMuted,
        secondary = Terracotta, outline = Color(0xFFD8D3C9),
        error = Color(0xFFB85E4B)
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(
        bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 26.sp, color = scheme.onSurface),
        bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 22.sp, color = scheme.onSurface),
        titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
        labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium)
    ), content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: ChatViewModel) {
    val chats by vm.chats.collectAsState()
    val cur by vm.currentId.collectAsState()
    val busy by vm.busy.collectAsState()
    val pending by vm.pending.collectAsState()
    val deep by vm.deepThink.collectAsState()
    val err by vm.error.collectAsState()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var showSettings by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val chat = chats.find { it.id == cur }

    LaunchedEffect(err) { err?.let { snack.showSnackbar(it); vm.error.value = null } }

    ModalNavigationDrawer(
        drawerState = drawer,
        scrimColor = MaterialTheme.colorScheme.scrim.copy(alpha = .28f),
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                drawerShape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                modifier = Modifier.widthIn(max = 340.dp).fillMaxHeight()
            ) {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("DeepRoot", fontSize = 21.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("DR", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(20.dp))
                    FilledTonalButton(
                        onClick = { vm.newChat(); scope.launch { drawer.close() } },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
                    ) { Text("＋   新建对话") }
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("搜索对话") }, shape = RoundedCornerShape(15.dp),
                        leadingIcon = { Text("⌕", fontSize = 22.sp) }
                    )
                    Spacer(Modifier.height(14.dp))
                    Text("最近", color = MaterialTheme.colorScheme.outline, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    val filtered = chats.filter { it.title.contains(search, true) }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        itemsIndexed(filtered, key = { _, c -> c.id }) { _, c ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                                    .background(if (c.id == cur) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
                                    .clickable { vm.select(c.id); scope.launch { drawer.close() } }
                                    .padding(start = 12.dp, end = 4.dp, top = 11.dp, bottom = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(c.title.ifBlank { "新对话" }, Modifier.weight(1f), maxLines = 1, fontSize = 14.sp)
                                TextButton(onClick = { vm.delete(c.id) }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                                    Text("删除", color = MaterialTheme.colorScheme.outline, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .35f))
                    TextButton(onClick = { showSettings = true; scope.launch { drawer.close() } },
                        modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp)) {
                        Text("⚙    设置", modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(
                    title = {
                        AnimatedVisibility(chat != null, enter = fadeIn(tween(MotionDuration)), exit = fadeOut(tween(160))) {
                            Text(chat?.title.orEmpty(), maxLines = 1, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        }
                    },
                    navigationIcon = {
                        TextButton(onClick = { scope.launch { drawer.open() } }, contentPadding = PaddingValues(horizontal = 18.dp)) {
                            Text("☰", fontSize = 21.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    },
                    actions = {
                        TextButton(onClick = { if (!busy) vm.newChat() }, contentPadding = PaddingValues(horizontal = 16.dp)) {
                            Text("＋", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            bottomBar = {
                var draft by remember { mutableStateOf("") }
                Column(
                    Modifier.fillMaxWidth().imePadding()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    AnimatedVisibility(showTools) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AssistChip(onClick = { vm.deepThink.value = !deep }, label = { Text(if (deep) "深度思考：开" else "深度思考：关") })
                                    AssistChip(onClick = { showTools = false }, label = { Text("联网搜索：待接入") })
                                }
                                Text("附件与 Root 终端工具", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                                Text("Root 命令由 AI 提出后，仍须逐条确认。", fontSize = 12.sp)
                            }
                        }
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(25.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .35f))
                    ) {
                        Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp)) {
                            BasicTextField(
                                value = draft, onValueChange = { draft = it },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 34.dp, max = 132.dp),
                                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, lineHeight = 23.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                                decorationBox = { inner ->
                                    Box {
                                        if (draft.isEmpty()) Text("和 DeepRoot 聊聊…", color = MaterialTheme.colorScheme.outline, fontSize = 16.sp)
                                        inner()
                                    }
                                }
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = MaterialTheme.colorScheme.background,
                                    shape = CircleShape,
                                    modifier = Modifier.size(36.dp).clickable { showTools = !showTools }
                                ) { Box(contentAlignment = Alignment.Center) { Text("＋", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurface) } }
                                Spacer(Modifier.width(8.dp))
                                FilterChip(selected = deep, onClick = { vm.deepThink.value = !deep },
                                    label = { Text("深度思考", fontSize = 12.sp) }, leadingIcon = {
                                        Text("✳", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                                    })
                                Spacer(Modifier.weight(1f))
                                AnimatedContent(targetState = busy || draft.isNotBlank(), label = "send-toggle") { sending ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = CircleShape,
                                        modifier = Modifier.size(38.dp).clickable {
                                            if (busy) vm.stop() else if (draft.isNotBlank()) {
                                                vm.send(draft.trim()); draft = ""
                                            }
                                        }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(if (sending && busy) "■" else "↑", color = MaterialTheme.colorScheme.onPrimary,
                                                fontSize = if (sending && busy) 15.sp else 23.sp, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text("DeepRoot 可能会出错，请核实重要信息。", modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 7.dp),
                        color = MaterialTheme.colorScheme.outline, fontSize = 10.sp)
                }
            }
        ) { padding ->
            val msgs = chat?.msgs.orEmpty()
            val results = remember(msgs) { msgs.filter { it.role == "tool" }.associateBy { it.toolCallId ?: "" } }
            val shown = msgs.filter { it.role != "tool" }
            val listState = rememberLazyListState()
            var followLatest by remember { mutableStateOf(true) }
            LaunchedEffect(listState) {
                snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
                    .collect { (index, _) -> followLatest = index >= (shown.size - 3).coerceAtLeast(0) }
            }
            LaunchedEffect(shown.size, shown.lastOrNull()?.content?.length, shown.lastOrNull()?.reasoning?.length) {
                if (shown.isNotEmpty() && followLatest) listState.animateScrollToItem(shown.lastIndex)
            }
            Box(Modifier.fillMaxSize().padding(padding)) {
                if (shown.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(horizontal = 30.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("DeepRoot", fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
                        Spacer(Modifier.height(9.dp))
                        Text("给思考留一点空间。", color = MaterialTheme.colorScheme.outline, fontSize = 15.sp)
                        Spacer(Modifier.height(30.dp))
                        listOf("解释一个复杂概念", "帮我检查一段代码", "如何安全地管理 Root 权限？").forEach { suggestion ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { vm.send(suggestion) }
                            ) { Text(suggestion, Modifier.padding(horizontal = 16.dp, vertical = 13.dp), fontSize = 14.sp) }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(22.dp)
                    ) {
                        itemsIndexed(shown, key = { index, _ -> "${chat?.id}:$index" }) { index, message ->
                            MsgItem(message, results, index == shown.lastIndex, busy) { vm.regenerate() }
                        }
                    }
                    AnimatedVisibility(
                        visible = !followLatest && shown.isNotEmpty(),
                        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 12.dp),
                        enter = fadeIn() + scaleIn(), exit = fadeOut()
                    ) {
                        FilledTonalButton(onClick = { scope.launch { listState.animateScrollToItem((shown.size - 1).coerceAtLeast(0)); followLatest = true } }) {
                            Text("↓ 回到底部")
                        }
                    }
                }
            }
        }
    }

    pending?.let { ApproveDialog(it) { ok -> vm.approve(ok) } }
    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun MsgItem(m: Msg, results: Map<String, Msg>, isLast: Boolean, busy: Boolean, onRegen: () -> Unit) {
    if (m.role == "user") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(20.dp),
                modifier = Modifier.widthIn(max = 320.dp)) {
                Text(m.content, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), fontSize = 15.sp, lineHeight = 23.sp)
            }
        }
        return
    }
    Column(Modifier.fillMaxWidth()) {
        if (m.reasoning.isNotEmpty()) {
            var open by remember { mutableStateOf(false) }
            Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f),
                shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().clickable { open = !open }) {
                Column(Modifier.padding(12.dp)) {
                    Text(if (open) "⌄ 思考过程" else "› 思考过程", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    AnimatedVisibility(open, enter = fadeIn(tween(180)), exit = fadeOut(tween(120))) {
                        Text(m.reasoning, modifier = Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp, lineHeight = 21.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        if (m.content.isNotEmpty()) Markdown(m.content)
        m.toolCalls.forEach { tc -> ToolCard(tc, results[tc.id]) }
        if (m.content.isEmpty() && m.reasoning.isEmpty() && m.toolCalls.isEmpty() && busy && isLast) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("正在整理思路…", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp)
            }
        }
        if (isLast && !busy && m.content.isNotEmpty()) {
            val clip = LocalClipboardManager.current
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { clip.setText(AnnotatedString(m.content)) }) { Text("复制", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline) }
                TextButton(onClick = onRegen) { Text("重新生成", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline) }
            }
        }
    }
}

@Composable
fun Markdown(text: String) {
    val ctx = LocalContext.current
    val markwon = remember { Markwon.create(ctx) }
    val color = MaterialTheme.colorScheme.onSurface.toArgb()
    val linkColor = MaterialTheme.colorScheme.primary.toArgb()
    AndroidView(
        factory = { TextView(it).apply {
            textSize = 16f
            setTextIsSelectable(true)
            typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.NORMAL)
            setLineSpacing(7f, 1.08f)
            setPadding(0, 0, 0, 0)
        } },
        update = {
            it.setTextColor(color)
            it.setLinkTextColor(linkColor)
            markwon.setMarkdown(it, text)
        },
    )
}

@Composable
fun ToolCard(tc: ToolCall, result: Msg?) {
    val args = runCatching { org.json.JSONObject(tc.args) }.getOrNull()
    val cmd = args?.optString("command").orEmpty()
    val why = args?.optString("reason").orEmpty()
    var expand by remember { mutableStateOf(false) }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = CardShape,
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .3f))
    ) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ROOT TERMINAL", fontSize = 10.sp, letterSpacing = 1.1.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(if (isDangerous(cmd)) "高风险" else "待确认", fontSize = 11.sp, color = if (isDangerous(cmd)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline)
            }
            if (why.isNotBlank()) Text(why, modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
            Surface(color = MaterialTheme.colorScheme.background, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(top = 9.dp)) {
                Text("$ $cmd", fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 19.sp,
                    modifier = Modifier.padding(12.dp))
            }
            when {
                result == null -> Text("等待用户确认…", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                result.denied -> Text("已拒绝 · 未执行", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                else -> {
                    Text(if (expand) "⌄ 终端输出" else "› 查看终端输出", modifier = Modifier.padding(top = 10.dp).clickable { expand = !expand },
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    AnimatedVisibility(expand) {
                        Text(result.content, modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState()).padding(top = 8.dp),
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ApproveDialog(p: Pending, onDecide: (Boolean) -> Unit) {
    var secondConfirm by remember(p.callId) { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = {},
        title = { Text(if (p.dangerous) "请再次确认高风险命令" else "允许执行终端命令？") },
        text = {
            Column {
                if (p.reason.isNotBlank()) Text(p.reason, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                    Text(p.command, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp).heightIn(max = 180.dp).verticalScroll(rememberScrollState()))
                }
                Spacer(Modifier.height(12.dp))
                Text("命令将以 Root 权限执行。DeepRoot 不会自动执行命令。", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                if (p.dangerous) Text("此操作可能影响系统或造成数据丢失。", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (p.dangerous && !secondConfirm) secondConfirm = true else onDecide(true)
                },
                colors = if (p.dangerous) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.buttonColors()
            ) { Text(if (p.dangerous && !secondConfirm) "我已了解风险，继续" else "确认执行") }
        },
        dismissButton = { TextButton(onClick = { onDecide(false) }) { Text("拒绝") } },
    )
}

@Composable
fun SettingsDialog(vm: ChatViewModel, onClose: () -> Unit) {
    val s = vm.settings.collectAsState().value
    val root by vm.rootState.collectAsState()
    var key by remember { mutableStateOf(s.apiKey) }
    var base by remember { mutableStateOf(s.baseUrl) }
    var sys by remember { mutableStateOf(s.system) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("设置") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("模型连接", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(key, { key = it }, label = { Text("API Key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(base, { base = it }, label = { Text("API Base URL") }, singleLine = true)
                OutlinedTextField(sys, { sys = it }, label = { Text("系统提示词") }, minLines = 3, maxLines = 6)
                HorizontalDivider()
                Text("Root 权限", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("状态：" + when (root) { true -> "已授予"; false -> "未授予"; null -> "未检测" }, Modifier.weight(1f))
                    OutlinedButton(onClick = { vm.checkRoot() }) { Text("检测 / 授予") }
                }
                Text("每条 Root 命令都必须由你明确确认；高风险命令需要二次确认。", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            }
        },
        confirmButton = { Button(onClick = { vm.saveSettings(Settings(key.trim(), base.trim(), sys)); onClose() }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onClose) { Text("取消") } },
    )
}
