# DeepRoot 2.2 附件解析

- 图片：JPEG、PNG、GIF、WebP，通过 DeepSeek Files API 上传并在对话中引用。
- 文档：PDF、DOC、DOCX、PPT、PPTX，通过 DeepSeek Files API 文档解析。
- 文本/数据：TXT、MD、CSV、JSON、XLS、XLSX、EPUB、MOBI，以及 KT/Java/Python/JS/HTML/XML/LOG 源码文本。
- PDF 和 PPT/PPTX 使用 rich_layout_recognition，以便模型读取文档中的图表/插图（若服务识别到）。其他文档使用 text_recognition；纯文本和表格使用 user_data。
- 文件选择后会显示在输入区，可移除；发送时才上传。成功上传后保存 file_id，后续多轮复用，不重复上传。
- 视频格式不在选择器中，也不会上传或解析。
- DeepSeek 官方限制：图片 64 MiB；PDF/Word/PPT 100 MiB；纯文本/表格/电子书 32 MiB。每次请求最多 20 个文档，解析文档文字合计 8 MiB。

注意：文件解析与图文识别会产生相应 API 用量；rich layout 文档中被识别出的图片还会计入视觉输入 Token。
