package com.deeproot.app

import android.content.Context
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 旋转锁定守卫：命令执行期间 + 结束后 15 秒内，实时监听 accelerometer_rotation / user_rotation，
 * 一旦被改动（无论是命令直接改、脚本间接改，还是后台进程延迟改）就立刻用 root 写回原值。
 */
private class RotationGuard(private val ctx: Context) {
    private val keys = listOf("accelerometer_rotation", "user_rotation")
    private val expected = HashMap<String, Int>()
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { restoreIfChanged() }
    }

    private fun read(key: String): Int? =
        runCatching { Settings.System.getInt(ctx.contentResolver, key) }.getOrNull()

    fun start() {
        for (k in keys) read(k)?.let { expected[k] = it }
        for (k in keys) runCatching {
            ctx.contentResolver.registerContentObserver(Settings.System.getUriFor(k), false, observer)
        }
    }

    fun restoreIfChanged() {
        for ((k, v) in expected) {
            val now = read(k)
            if (now != null && now != v) Shell.cmd("settings put system $k $v").submit()
        }
    }

    fun stop() {
        restoreIfChanged()
        runCatching { ctx.contentResolver.unregisterContentObserver(observer) }
    }
}

object RootShell {
    private var appCtx: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    /** 首次调用会触发 su 授权弹窗（Magisk / KernelSU / APatch 均可） */
    suspend fun isRoot(): Boolean = withContext(Dispatchers.IO) { Shell.getShell().isRoot }

    private fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** 明确会改动“自动旋转 / 旋转锁定”的命令，直接拦截（含 wm / cmd window 的各种写法，以及 settings reset 批量重置） */
    private val rotationTouch = Regex(
        "accelerometer_rotation|user_rotation|user-rotation|ignore-orientation-request|settings\\s+reset",
        RegexOption.IGNORE_CASE
    )

    /** 仅在用户批准后调用。30 秒超时，输出截断到 8000 字符。 */
    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        if (!Shell.getShell().isRoot) return@withContext "错误：尚未获得 root 权限"
        if (rotationTouch.containsMatchIn(cmd)) {
            return@withContext "已拦截：该命令会修改屏幕旋转 / 旋转锁定设置（或批量重置系统设置），DeepRoot 不会执行。如确实需要，请用户手动在系统设置里调整。"
        }
        val guard = appCtx?.let { RotationGuard(it).also { g -> g.start() } }
        val r = try {
            Shell.cmd("timeout 30 sh -c " + quote(cmd)).exec()
        } finally {
            // 命令结束后再多盯 15 秒，覆盖后台进程延迟修改的情况
            guard?.let { g -> scope.launch { delay(15_000); g.stop() } }
        }
        val out = r.out.joinToString("\n").take(8000)
        val err = r.err.joinToString("\n").take(2000)
        buildString {
            append("exit=").append(r.code)
            if (out.isNotEmpty()) append("\n[stdout]\n").append(out)
            if (err.isNotEmpty()) append("\n[stderr]\n").append(err)
        }
    }
}
