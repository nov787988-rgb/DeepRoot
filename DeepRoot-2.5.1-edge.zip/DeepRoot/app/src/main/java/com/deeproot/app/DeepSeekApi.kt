package com.deeproot.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class DeepSeekApi {
    private val client = OkHttpClient.Builder().readTimeout(180, TimeUnit.SECONDS).build()

    data class Result(val content: String, val reasoning: String, val toolCalls: List<ToolCall>)

    /** Fetch model IDs from an OpenAI-compatible /models endpoint. */
    suspend fun listModels(base: String, key: String): List<String> = withContext(Dispatchers.IO) {
        val endpoint = base.trim().trimEnd('/') + "/models"
        val req = Request.Builder().url(endpoint)
            .header("Authorization", "Bearer $key")
            .header("Accept", "application/json")
            .get().build()
        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException("获取模型失败 HTTP ${resp.code}：${raw.take(300)}")
            val data = JSONObject(raw).optJSONArray("data") ?: throw IOException("模型接口返回格式不正确：缺少 data 数组")
            val ids = (0 until data.length()).mapNotNull { i ->
                data.optJSONObject(i)?.optString("id")?.trim()?.takeIf { it.isNotEmpty() }
            }.distinct()
            if (ids.isEmpty()) throw IOException("模型接口返回成功，但没有可用模型")
            ids
        }
    }
    suspend fun uploadFile(context: Context, base: String, key: String, attachment: Attachment): String = withContext(Dispatchers.IO) {
        val uri = Uri.parse(attachment.uri)
        val resolver = context.contentResolver
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("无法读取附件：${attachment.name}")
        val max = when { attachment.mime.startsWith("image/") -> 64L * 1024 * 1024; attachment.mime in setOf("text/plain", "text/markdown", "text/csv", "application/json") || attachment.name.endsWith(".xlsx", true) || attachment.name.endsWith(".xls", true) -> 32L * 1024 * 1024; else -> 100L * 1024 * 1024 }
        if (bytes.size.toLong() > max) throw IOException("附件超过大小限制：${attachment.name}")
        val purpose = when {
            attachment.mime.startsWith("image/") -> "user_data"
            attachment.name.substringAfterLast('.', "").lowercase() in setOf("txt", "md", "csv", "json", "xlsx", "xls", "epub", "mobi", "kt", "java", "py", "js", "html", "xml", "log") -> "user_data"
            attachment.name.substringAfterLast('.', "").lowercase() in setOf("pdf", "ppt", "pptx") -> "rich_layout_recognition"
            else -> "text_recognition"
        }
        val fileBody = bytes.toRequestBody((attachment.mime.ifBlank { "application/octet-stream" }).toMediaType())
        val multipart = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose", purpose)
            .addFormDataPart("file", attachment.name, fileBody).build()
        val req = Request.Builder().url(base.trimEnd('/') + "/files")
            .header("Authorization", "Bearer $key").post(multipart).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("附件上传失败 HTTP ${resp.code}：${resp.body?.string()?.take(300)}")
            JSONObject(resp.body?.string().orEmpty()).optString("id").takeIf { it.isNotBlank() }
                ?: throw IOException("附件上传成功但没有返回 file_id")
        }
    }

    private class Acc(var id: String = "", var name: String = "", val args: StringBuilder = StringBuilder())

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k)

    /** OpenAI 兼容的流式 /chat/completions；回调逐段返回思考与正文 */
    suspend fun stream(
        base: String, key: String, model: String, messages: JSONArray, tools: JSONArray, thinking: Boolean,
        onReasoning: (String) -> Unit, onContent: (String) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val payload = JSONObject().put("model", model).put("messages", messages).put("tools", tools).put("stream", true)
        if (model == "deepseek-flash") payload.put("thinking", JSONObject().put("type", if (thinking) "enabled" else "disabled"))
        val body = payload.toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(base.trimEnd('/') + "/chat/completions")
            .header("Authorization", "Bearer $key").post(body).build()
        val call = client.newCall(req)
        val handle = coroutineContext[Job]!!.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}：${resp.body?.string()?.take(300)}")
                val src = resp.body!!.source()
                val c = StringBuilder(); val r = StringBuilder()
                val acc = sortedMapOf<Int, Acc>()
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.removePrefix("data:").trim()
                    if (d == "[DONE]") break
                    if (d.isEmpty()) continue
                    val delta = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: continue
                    delta.str("reasoning_content").takeIf { it.isNotEmpty() }?.let { r.append(it); onReasoning(it) }
                    delta.str("content").takeIf { it.isNotEmpty() }?.let { c.append(it); onContent(it) }
                    delta.optJSONArray("tool_calls")?.let { arr ->
                        for (i in 0 until arr.length()) {
                            val t = arr.getJSONObject(i)
                            val a = acc.getOrPut(t.optInt("index", i)) { Acc() }
                            t.str("id").takeIf { it.isNotEmpty() }?.let { a.id = it }
                            t.optJSONObject("function")?.let { f ->
                                f.str("name").takeIf { it.isNotEmpty() }?.let { a.name = it }
                                a.args.append(f.str("arguments"))
                            }
                        }
                    }
                }
                Result(c.toString(), r.toString(), acc.values.map { ToolCall(it.id, it.name, it.args.toString()) })
            }
        } finally {
            handle.dispose()
        }
    }
}
