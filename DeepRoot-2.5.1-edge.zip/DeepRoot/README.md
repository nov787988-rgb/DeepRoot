# DeepRoot 2.5.1 — Axon 设计融合版 Android Root 助手

本项目是 Android 原生应用（Kotlin、Jetpack Compose），不是网页项目。Root 命令由 `libsu` 调用设备上的 `su`，兼容 Magisk / KernelSU / APatch（取决于设备环境）。

## 核心流程

1. DeepSeek Chat Completions 通过流式 Function Calling 请求 `run_shell`。
2. `ChatViewModel` 将命令、用途和风险级别放进聊天消息流内的指令卡片。
3. 用户逐条点击“确认执行”或“拒绝”。不点击确认不会执行命令。
4. 确认后才调用 `RootShell.exec()`；输出和退出码回传模型继续分析。
5. 命令有 30 秒超时，stdout 截断 8000 字符，stderr 截断 2000 字符。

## 构建 Debug APK

要求 Android Studio、JDK 17、Android SDK 35。

```bash
./gradlew assembleDebug
```

APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。Debug APK 使用 Android 默认 debug 签名，可直接安装测试。

## Release 签名（固定签名，2.5.1 沿用）

本源码包包含 `app/deeproot-release-2026.jks`，Gradle Release 构建固定使用 alias `deeproot-release-2026`。GitHub Actions 无需配置 Secrets，会自动构建并验证签名。该 JKS 仅随此私有源码包提供，切勿上传到公开仓库。

固定签名参数：
- Keystore：`app/deeproot-release-2026.jks`
- Store password / Key password：`DR240!2026#ReleaseKey`
- Key alias：`deeproot-release-2026`

**重要：** 这是新生成的签名身份，与 DeepRoot 2.3.0 原签名不同。使用此签名的 2.4.0 APK 不能覆盖安装原签名的 2.3.0；需要先卸载旧版（会影响本地应用数据），或继续使用旧签名密钥。请安全备份 JKS，未来所有使用此新签名发布的版本必须复用同一 JKS。不要公开发布此源码包或密钥。

## DeepSeek 配置

首次启动后进入“设置”，填写 DeepSeek API Key、Base URL 和模型。API Key 通过 AndroidX EncryptedSharedPreferences 本地加密保存。

## Root 安全边界

- 每条模型提出的命令都需要用户单独确认；没有“始终允许”。
- 拒绝的命令作为 tool result 返回模型，不会执行。
- 高危命令有额外风险提示。
- Root 授权由系统的 su 管理器弹出，应用不能绕过授权。
- 请勿对不理解的命令授权；Root 命令可能造成数据丢失或设备无法启动。

## 当前实现范围

现有版本包含流式对话、Markdown、思考过程、会话历史、模型选择、联网工具开关、文档/图片附件上传和内嵌 Root 审批卡片。原始项目尚未实现视频帧抽取/视频理解；不能把普通文件上传误称为视频多模态识别。

## 2.5.1 变更

- 联网搜索重构：移除 Bing / DuckDuckGo HTML 正则解析，改用 DeepSeek 官方 Search API：`POST /v1/tools/search`。
- 网页阅读重构：新增 DeepSeek 官方 Fetch API：`POST /v1/tools/fetch`，返回 Markdown 正文。
- 搜索与阅读仍通过 Function Calling 暴露给模型，因此保留 `run_shell` Root 工具；每条 Root 命令依旧必须逐条人工确认。
- 继续复用现有 DeepSeek API Key，不需要 Tavily 或其他第三方密钥。官方 Search / Fetch 按成功请求计费，详见 DeepSeek 官方文档。
- UI 借鉴 Axon 的聊天优先布局、圆润卡片、快捷提问和蓝白强调色，保留 DeepRoot 原生 Compose、边缘模糊、Root 审批和现有交互。
- 版本号 2.5.1（versionCode 8），固定签名文件及签名配置保持不变。

## 联网工作方式与限制

DeepRoot 使用 DeepSeek 官方 Search & Fetch 原始 API，而不是 `deepseek_web_search` 服务端工具。官方服务端工具目前不能与自定义 Function Calling 工具同时声明；如果同时启用它们，Root 的 `run_shell` 工具将无法保留。因此本版本采用官方 Search / Fetch API + 本地 Function Calling 调度，在不牺牲 Root 功能的前提下实现联网。Search 与 Fetch 均需官方 `https://api.deepseek.com` Base URL，使用同一 API Key。官方价格为每 1,000 次成功请求各 0.75 美元；空结果或失败请求不计费。详见 https://api-docs.deepseek.com/guides/search/ 。

**安全提醒：** `app/deeproot-release-2026.jks` 是发布签名私钥。请勿将含 JKS 的源码包或密钥提交到公开仓库；仅在可信的私有构建环境中使用。不要更改现有 JKS，否则会导致更新签名不一致。


## 2.5.1 模型管理
- 支持通过当前 API Base URL 的 `/models` 接口自动获取模型 ID。
- 支持手动输入模型 ID、刷新模型列表及缓存上次成功结果。
- 模型缓存随 API 地址与 Key 指纹隔离，避免不同服务商配置串用。
