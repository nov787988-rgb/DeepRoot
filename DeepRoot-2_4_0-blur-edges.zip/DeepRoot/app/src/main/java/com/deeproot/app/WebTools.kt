package com.deeproot.app

import android.text.Html
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * 本地联网工具：由 App 自己发请求，不依赖中转/服务端是否支持内置联网搜索。
 * web_search：先 Bing，失败再 DuckDuckGo；read_url：抓取网页并提取正文文本。
 */
object WebTools {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private class Hit(val title: String, val url: String, val snippet: String)

    private fun get(url: String): String {
        val req = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return (r.body?.string().orEmpty()).take(600_000)
        }
    }

    private fun clean(html: String): String =
        Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()

    // ---------- 搜索 ----------

    private fun unwrapBing(href: String): String {
        val h = href.replace("&amp;", "&")
        if (!h.contains("bing.com/ck/a")) return h
        val u = Regex("[?&]u=([^&]+)").find(h)?.groupValues?.get(1) ?: return h
        val decoded = runCatching { URLDecoder.decode(u, "UTF-8") }.getOrDefault(u)
        if (!decoded.startsWith("a1")) return h
        val b64 = decoded.substring(2).trimEnd('=')
        return runCatching {
            String(Base64.decode(b64, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP), Charsets.UTF_8)
        }.getOrDefault(h)
    }

    private fun searchBing(q: String): List<Hit> {
        val html = get("https://www.bing.com/search?q=" + URLEncoder.encode(q, "UTF-8") + "&setlang=zh-Hans&mkt=zh-CN")
        val item = Regex("""<li class="b_algo"[\s\S]*?</li>""")
        val link = Regex("""<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)</a>""")
        val snip = Regex("""<p[^>]*>([\s\S]*?)</p>""")
        return item.findAll(html).mapNotNull { m ->
            val block = m.value
            val l = link.find(block) ?: return@mapNotNull null
            val url = unwrapBing(l.groupValues[1])
            if (!url.startsWith("http")) return@mapNotNull null
            Hit(clean(l.groupValues[2]), url, snip.find(block)?.let { clean(it.groupValues[1]) }.orEmpty())
        }.toList()
    }

    private fun searchDdg(q: String): List<Hit> {
        val html = get("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
        val link = Regex("""class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)</a>""")
        val snip = Regex("""class="result__snippet"[^>]*>([\s\S]*?)</a>""")
        val snips = snip.findAll(html).map { clean(it.groupValues[1]) }.toList()
        return link.findAll(html).mapIndexedNotNull { i, m ->
            var url = m.groupValues[1].replace("&amp;", "&")
            Regex("[?&]uddg=([^&]+)").find(url)?.let {
                url = runCatching { URLDecoder.decode(it.groupValues[1], "UTF-8") }.getOrDefault(url)
            }
            if (url.startsWith("//")) url = "https:$url"
            if (!url.startsWith("http")) return@mapIndexedNotNull null
            Hit(clean(m.groupValues[2]), url, snips.getOrNull(i).orEmpty())
        }.toList()
    }

    suspend fun search(query: String): String = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext "错误：缺少 query 参数"
        val errors = mutableListOf<String>()
        val engines = listOf<Pair<String, (String) -> List<Hit>>>(
            "Bing" to { s: String -> searchBing(s) },
            "DuckDuckGo" to { s: String -> searchDdg(s) },
        )
        for ((name, fn) in engines) {
            val hits = try { fn(q) } catch (e: Exception) { errors += "$name: ${e.message}"; emptyList() }
            if (hits.isNotEmpty()) {
                return@withContext hits.take(6).mapIndexed { i, h ->
                    "${i + 1}. ${h.title}\n   ${h.url}" + if (h.snippet.isNotBlank()) "\n   ${h.snippet.take(300)}" else ""
                }.joinToString("\n")
            }
            if (errors.none { it.startsWith(name) }) errors += "$name: 无结果"
        }
        "搜索失败（${errors.joinToString("；")}）。可能是网络无法访问搜索引擎，请告知用户。"
    }

    // ---------- 读取网页 ----------

    private val privateHost = Regex(
        "^(localhost|.*\\.local|127\\..*|10\\..*|192\\.168\\..*|169\\.254\\..*|172\\.(1[6-9]|2\\d|3[01])\\..*|0\\.0\\.0\\.0|\\[?::1\\]?)$",
        RegexOption.IGNORE_CASE
    )

    suspend fun readUrl(url: String): String = withContext(Dispatchers.IO) {
        val u = url.trim()
        val host = runCatching { URI(u).host }.getOrNull()
        if (!(u.startsWith("http://") || u.startsWith("https://")) || host.isNullOrBlank()) return@withContext "错误：url 无效"
        if (privateHost.matches(host)) return@withContext "已拦截：不允许读取本机或内网地址"
        try {
            val html = get(u)
            val title = Regex("""<title[^>]*>([\s\S]*?)</title>""", RegexOption.IGNORE_CASE).find(html)?.let { clean(it.groupValues[1]) }.orEmpty()
            val body = html
                .replace(Regex("""<(script|style|noscript|svg|nav|footer|header)[\s\S]*?</\1>""", RegexOption.IGNORE_CASE), " ")
                .replace(Regex("""<!--[\s\S]*?-->"""), " ")
                .replace(Regex("""<(br|p|div|li|h[1-6]|tr)[^>]*>""", RegexOption.IGNORE_CASE), "\n")
            val text = Html.fromHtml(body, Html.FROM_HTML_MODE_LEGACY).toString()
                .lines().map { it.replace(Regex("[ \\t\\u00A0]+"), " ").trim() }.filter { it.isNotEmpty() }
                .joinToString("\n")
            "标题：$title\n链接：$u\n\n" + text.take(6000) + if (text.length > 6000) "\n…（已截断）" else ""
        } catch (e: Exception) {
            "读取失败：${e.message}"
        }
    }
}
